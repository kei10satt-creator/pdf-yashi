import {PDFDocument} from './lib/pdf-lib.mjs';
import {similarity,adjust,point,buildPlacement,symbolStyle,VIEW_SCALE} from './registration.mjs';
const element=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n};
const button=(text,fn)=>{const b=element('button',text);b.type='button';b.onclick=()=>Promise.resolve().then(fn).catch(e=>alert(e.message));return b};
const identity=()=>({a:1,b:0,tx:0,ty:0});
const MM=VIEW_SCALE*72/25.4;
export async function openPdfUpdate({source,pdfjs,commit,number}){
 const dialog=element('dialog');dialog.className='pdfUpdate';
 dialog.innerHTML='<h2>元図PDFの更新</h2><p>旧図の基準点1・2、新図の同じ位置の1・2を指定します。位置・縮尺・回転を合わせ、重ね合わせで確認してから確定してください。</p>';
 const mode=element('select');mode.setAttribute('aria-label','更新方法');for(const [value,label] of [['replace','元図PDFを差し替える'],['copy','新しいPDFへ載せ替える']]){const o=element('option',label);o.value=value;mode.append(o)}
 const name=element('input');name.value=source.name+'（載せ替え）';name.setAttribute('aria-label','新しい案件名');name.disabled=true;mode.onchange=()=>name.disabled=mode.value!=='copy';
 const file=element('input');file.type='file';file.accept='application/pdf';file.setAttribute('aria-label','新しい元図PDF');file.disabled=true;
 dialog.append(mode,name,file);
 const status=element('p','元図を読み込み中…'),mapping=element('div'),workspace=element('div');workspace.className='registrationWorkspace';dialog.append(status,mapping,workspace);
 const sources=element('div');sources.className='registrationSources';const oldCanvas=element('canvas'),newCanvas=element('canvas'),overlay=element('canvas');
 for(const [label,canvas] of [['旧図：基準点1 → 2',oldCanvas],['新図：同じ位置の1 → 2',newCanvas]]){const section=element('section');section.append(element('h3',label));const shell=element('div');shell.className='registrationShell';shell.append(canvas);section.append(shell);sources.append(section)}
 workspace.append(sources);
 const controls=element('div');controls.className='registrationControls';
 const zoom=element('input');zoom.type='range';zoom.min='100';zoom.max='300';zoom.value='100';zoom.setAttribute('aria-label','基準点の表示拡大');zoom.oninput=()=>{oldCanvas.style.width=newCanvas.style.width=zoom.value+'%'};controls.append(element('label','基準点の表示拡大'),zoom);
 const fields={};for(const [key,label,value,step] of [['x','横移動（用紙上mm）',0,.1],['y','縦移動（用紙上mm・下が正）',0,.1],['degrees','回転の微調整（度・時計回り）',0,.1],['percent','縮尺の微調整（%）',100,.1]]){const l=element('label',label),input=element('input');input.type='number';input.value=value;input.step=step;input.setAttribute('aria-label',label);l.append(input);controls.append(l);fields[key]=input;input.oninput=()=>{const m=current();if(m){m.fine[key]=Number(input.value);m.confirmed=false;preview();updateLabels()}}}
 const symbols=element('input');symbols.type='checkbox';const symLabel=element('label','記号の表示サイズも配置の縮尺に合わせる');symLabel.prepend(symbols);symbols.onchange=()=>{const m=current();if(m){m.scaleSymbols=symbols.checked;m.confirmed=false;preview();updateLabels()}};controls.append(symLabel,element('p','チェックなし：丸・数字・矢印線は現在の表示サイズを維持します。配置位置と向きは常に変換します。'));
 workspace.append(controls,element('h3','重ね合わせプレビュー（新図＋位置合わせした旧図＋矢視）'));
 const opacity=element('input');opacity.type='range';opacity.min='0';opacity.max='100';opacity.value='35';opacity.setAttribute('aria-label','旧図の濃さ');opacity.oninput=preview;workspace.append(element('label','旧図の濃さ'),opacity,overlay);
 const detail=element('p');workspace.append(detail);
 const reset=button('このページの基準点をやり直す',()=>{const m=current();m.oldPoints=[];m.newPoints=[];m.confirmed=false;preview();paintPins();updateLabels()});
 const confirmPage=button('このページの位置合わせを確認',()=>{current().transform=matrix();current().confirmed=true;updateLabels()});workspace.append(reset,confirmPage);
 const footer=element('div');footer.className='registrationFooter';const apply=button('プレビューの内容で確定',applyUpdate),cancel=button('キャンセル',()=>finish(false));apply.disabled=true;footer.append(apply,cancel);dialog.append(footer);
 let oldDoc,newDoc,newBytes,newName,maps=[],oldSizes={},newSizes={},selected=1,oldImage,newImage,busy=false,closed=false,epoch=0,resolve;
 const completed=new Promise(r=>resolve=r);const current=()=>maps.find(m=>m.old===selected);
 function finish(value){if(closed||busy)return;closed=true;epoch++;dialog.close();dialog.remove();oldDoc?.loadingTask.destroy().catch(console.warn);newDoc?.loadingTask.destroy().catch(console.warn);resolve(value)}
 dialog.addEventListener('cancel',e=>{e.preventDefault();finish(false)});document.body.append(dialog);dialog.showModal();workspace.hidden=true;
 const doc=bytes=>pdfjs.getDocument({data:new Uint8Array(bytes).slice(),cMapUrl:'./lib/cmaps/',cMapPacked:true,standardFontDataUrl:'./lib/standard_fonts/',wasmUrl:'./lib/wasm/',iccUrl:'./lib/iccs/'}).promise;
 async function sizes(d){const result={};for(let n=1;n<=d.numPages;n++){const p=await d.getPage(n),v=p.getViewport({scale:VIEW_SCALE});result[n]={width:Math.ceil(v.width),height:Math.ceil(v.height)}}return result}
 function matrix(){const m=current();return adjust(similarity(m.oldPoints,m.newPoints),{...m.fine,x:m.fine.x*MM,y:m.fine.y*MM},m.newPoints[0])}
 function updateLabels(){for(const row of mapping.children){const m=maps.find(x=>x.old===Number(row.dataset.old));if(m)row.querySelector('span').textContent=m.target==='keep'?'旧ページを追加して保持':m.confirmed?'位置合わせ確認済み':'位置合わせ未確認'}apply.disabled=busy||!maps.length||maps.some(m=>m.target!=='keep'&&!m.confirmed)}
 async function imageOf(d,n){const p=await d.getPage(n),v=p.getViewport({scale:VIEW_SCALE}),c=element('canvas');c.width=Math.ceil(v.width);c.height=Math.ceil(v.height);await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise;return c}
 async function show(n){const ticket=++epoch;selected=n;oldImage=newImage=null;const m=current();workspace.hidden=m.target==='keep';confirmPage.disabled=true;reset.disabled=true;
   for(const row of mapping.children)row.classList.toggle('selectedMapping',Number(row.dataset.old)===n);
   if(m.target==='keep'){status.textContent='旧'+n+'ページは新PDFの末尾にそのまま残します。矢視も保持します。';updateLabels();return}
   status.textContent='旧'+n+'ページ → 新'+m.target+'ページを表示中…';
   for(const key of Object.keys(fields))fields[key].value=m.fine[key];symbols.checked=m.scaleSymbols;
   const images=await Promise.all([imageOf(oldDoc,n),imageOf(newDoc,m.target)]);if(closed||ticket!==epoch)return;
   [oldImage,newImage]=images;for(const [canvas,img] of [[oldCanvas,oldImage],[newCanvas,newImage]]){canvas.width=img.width;canvas.height=img.height}
   overlay.width=newImage.width;overlay.height=newImage.height;status.textContent='旧'+n+'ページ → 新'+m.target+'ページ。基準点は離れた2点を選んでください。';reset.disabled=false;paintPins();preview();
 }
 function paintPins(){for(const [canvas,img,points] of [[oldCanvas,oldImage,current()?.oldPoints],[newCanvas,newImage,current()?.newPoints]]){if(!img)continue;const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.drawImage(img,0,0);for(const [i,p] of points.entries()){const radius=Math.max(12,canvas.width/65);c.fillStyle=i?'#dc7700':'#006bdf';c.beginPath();c.arc(p.x,p.y,radius,0,Math.PI*2);c.fill();c.font='bold '+radius*1.4+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='white';c.fillText(String(i+1),p.x,p.y)}}}
 for(const [canvas,key] of [[oldCanvas,'oldPoints'],[newCanvas,'newPoints']]){let start;canvas.addEventListener('pointerdown',e=>start={x:e.clientX,y:e.clientY});canvas.addEventListener('pointerup',e=>{if(!start||Math.hypot(e.clientX-start.x,e.clientY-start.y)>7||!oldImage||!newImage||busy)return;start=null;const r=canvas.getBoundingClientRect(),p={x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height},m=current();if(m[key].length===2)m[key]=[];m[key].push(p);m.confirmed=false;paintPins();preview();updateLabels()});canvas.addEventListener('pointercancel',()=>start=null)}
 function preview(){if(!oldImage||!newImage)return;const c=overlay.getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,overlay.width,overlay.height);c.globalAlpha=1;c.drawImage(newImage,0,0);confirmPage.disabled=true;
   try{const t=matrix(),m=current(),ratio=Math.hypot(t.a,t.b);c.save();c.globalAlpha=Number(opacity.value)/100;c.transform(t.a,t.b,-t.b,t.a,t.tx,t.ty);c.drawImage(oldImage,0,0);c.restore();
     const base={...source.style,...source.pageStyles?.[m.old]},s=symbolStyle({...base,symbolScale:(base.symbolScale||1)*(m.scaleSymbols?ratio:1)});let outside=0;
     for(const a of source.arrows.filter(a=>(a.page||1)===m.old)){const p=point(t,{x:a.x*oldImage.width,y:a.y*oldImage.height}),angle=a.angle+Math.atan2(t.b,t.a);if(p.x<0||p.y<0||p.x>overlay.width||p.y>overlay.height)outside++;drawArrow(c,p,angle,s,number(a))}
     detail.textContent='配置の縮尺 '+(ratio*100).toFixed(3)+'% ／ 回転 '+(Math.atan2(t.b,t.a)*180/Math.PI).toFixed(3)+'°'+(outside?' ／ 用紙外の矢視 '+outside+'件':'')+'。確定後も選択モードで個別調整できます。';confirmPage.disabled=false;
   }catch(e){detail.textContent=e.message}
 }
 file.onchange=async()=>{if(!file.files[0])return;busy=true;file.disabled=true;apply.disabled=true;try{const f=file.files[0],bytes=new Uint8Array(await f.arrayBuffer()),next=await doc(bytes),dimensions=await sizes(next);if(closed){await next.loadingTask.destroy();return}await newDoc?.loadingTask.destroy();newDoc=next;newBytes=bytes;newName=f.name;newSizes=dimensions;maps=Array.from({length:oldDoc.numPages},(_,i)=>({old:i+1,target:i<next.numPages?i+1:'keep',oldPoints:[],newPoints:[],fine:{x:0,y:0,degrees:0,percent:100},scaleSymbols:false,confirmed:false}));mapping.replaceChildren();
     for(const m of maps){const row=element('div');row.className='mappingRow';row.dataset.old=m.old;const select=element('select');select.setAttribute('aria-label','旧'+m.old+'ページの対応先');for(let n=1;n<=next.numPages;n++){const o=element('option','新'+n+'ページ');o.value=n;select.append(o)}const keep=element('option','旧ページを末尾に残す');keep.value='keep';select.append(keep);select.value=m.target;select.onchange=()=>{m.target=select.value==='keep'?'keep':Number(select.value);m.oldPoints=[];m.newPoints=[];m.confirmed=false;show(m.old).catch(e=>status.textContent=e.message);updateLabels()};row.append(element('b','旧'+m.old+'ページ → '),select,element('span'),button('位置合わせ',()=>show(m.old)));mapping.append(row)}
     busy=false;updateLabels();await show(1);
   }catch(e){status.textContent='PDFを読み込めません：'+e.message}finally{busy=false;file.disabled=false;updateLabels()}}
 async function applyUpdate(){if(busy||!newDoc)return;if(mode.value==='copy'&&!name.value.trim())throw Error('新しい案件名を入力してください');
   let nextPage=newDoc.numPages;const complete=maps.map(m=>m.target==='keep'?{...m,target:++nextPage,transform:identity(),scaleSymbols:false}:{...m});
   const dimensions={...newSizes};for(const m of complete)if(m.target>newDoc.numPages)dimensions[m.target]=oldSizes[m.old];
   const result=buildPlacement(source,complete,dimensions,oldSizes);if(result.outside&&!confirm('用紙外に'+result.outside+'件の矢視があります。位置合わせを確定しますか？'))return;
   busy=true;apply.disabled=true;cancel.disabled=true;file.disabled=true;status.textContent='PDFと矢視を保存しています…';
   try{let bytes=newBytes;if(nextPage>newDoc.numPages){const target=await PDFDocument.load(newBytes),original=await PDFDocument.load(source.pdfBytes);const kept=complete.filter(m=>m.target>newDoc.numPages);const copied=await target.copyPages(original,kept.map(m=>m.old-1));for(const p of copied)target.addPage(p);bytes=await target.save()}
     const record={...source,pdfBytes:bytes,pdfFileName:newName,arrows:result.arrows,pageStyles:result.pageStyles,currentPage:complete.find(m=>m.old===(source.currentPage||1))?.target||1,name:mode.value==='copy'?name.value.trim():source.name};
     await commit(record,mode.value);busy=false;finish(true);
   }catch(e){status.textContent='確定できませんでした。元の案件は保持しています：'+e.message}finally{busy=false;cancel.disabled=false;file.disabled=false;updateLabels()}
 }
 try{oldDoc=await doc(source.pdfBytes);oldSizes=await sizes(oldDoc);if(closed){await oldDoc.loadingTask.destroy();return false}file.disabled=false;status.textContent='新しい元図PDFを選択してください。'}catch(e){status.textContent='元図を開けません：'+e.message}
 return completed;
}
function drawArrow(c,p,angle,s,n){const x=p.x+Math.cos(angle)*s.length,y=p.y+Math.sin(angle)*s.length;c.save();c.strokeStyle=c.fillStyle='#d00000';c.lineWidth=s.line;c.lineCap='round';c.beginPath();c.arc(p.x,p.y,s.circle,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(p.x+Math.cos(angle)*s.circle,p.y+Math.sin(angle)*s.circle);c.lineTo(x,y);c.stroke();c.beginPath();c.moveTo(x,y);c.lineTo(x-Math.cos(angle-Math.PI/7)*s.head,y-Math.sin(angle-Math.PI/7)*s.head);c.lineTo(x-Math.cos(angle+Math.PI/7)*s.head,y-Math.sin(angle+Math.PI/7)*s.head);c.closePath();c.fill();if(n!==null&&n!==undefined){c.font='bold '+s.fontSize+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(String(n),p.x,p.y,s.textWidth)}c.restore()}
