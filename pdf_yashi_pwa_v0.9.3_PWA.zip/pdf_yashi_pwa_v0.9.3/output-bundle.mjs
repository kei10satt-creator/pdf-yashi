export const outputModes=[['all','全写真'],['inspection12','12条用'],['report','報告用'],['survey','調査状況写真']];
const crcTable=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0});
function crc32(bytes){let c=0xffffffff;for(const b of bytes)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0}
// ZIP store method: no compression dependency, UTF-8 names, portable to Files and Explorer.
export async function makeZip(files){
 const chunks=[],directory=[];let offset=0,dirSize=0;
 for(const f of files){const data=new Uint8Array(await f.blob.arrayBuffer()),name=new TextEncoder().encode(f.name),crc=crc32(data);if(data.length>0xffffffff||offset>0xffffffff)throw Error('ZIPのサイズ上限を超えています。用途を分けて出力してください。');
  const local=new Uint8Array(30+name.length),l=new DataView(local.buffer);l.setUint32(0,0x04034b50,true);l.setUint16(4,20,true);l.setUint16(6,0x800,true);l.setUint16(12,33,true);l.setUint32(14,crc,true);l.setUint32(18,data.length,true);l.setUint32(22,data.length,true);l.setUint16(26,name.length,true);local.set(name,30);chunks.push(local,data);
  const central=new Uint8Array(46+name.length),c=new DataView(central.buffer);c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);c.setUint16(14,33,true);c.setUint32(16,crc,true);c.setUint32(20,data.length,true);c.setUint32(24,data.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);central.set(name,46);directory.push(central);dirSize+=central.length;offset+=local.length+data.length;
 }
 if(offset+dirSize>0xffffffff||files.length>65535)throw Error('ZIPのサイズ上限を超えています。');
 const end=new Uint8Array(22),v=new DataView(end.buffer);v.setUint32(0,0x06054b50,true);v.setUint16(8,files.length,true);v.setUint16(10,files.length,true);v.setUint32(12,dirSize,true);v.setUint32(16,offset,true);
 return new Blob([...chunks,...directory,end],{type:'application/zip'});
}
export async function saveOutputFiles(files,projectName,save){
 const bundled=files.length>1,blob=bundled?await makeZip(files):files[0].blob,name=bundled?projectName+'_用途別出力.zip':files[0].name;
 return new Promise(resolve=>{const d=document.createElement('dialog');d.className='nativeExport';const title=document.createElement('h3');title.textContent=bundled?'用途別ファイルをまとめて保存':'出力ファイルを保存';const list=document.createElement('ul');for(const f of files){const li=document.createElement('li');li.textContent=f.name;list.append(li)}const note=document.createElement('p');note.textContent=bundled?'用途ごとの全ページ入りファイルを、1つのZIPにまとめました。保存後に展開してご利用ください。':'保存先を選択してください。iPadでは「ファイルに保存」からBox等を選べます。';const go=document.createElement('button'),cancel=document.createElement('button');go.textContent='保存先を選んで書き出す';cancel.textContent='閉じる';let busy=false;const finish=()=>{d.close();d.remove();resolve()};cancel.onclick=()=>{if(!busy)finish()};go.onclick=async()=>{busy=true;go.disabled=cancel.disabled=true;try{const result=await save(blob,name);note.textContent=result==='downloaded'?'ダウンロード先でファイルをご確認ください。':'保存操作が完了しました。';go.textContent='もう一度保存する'}catch(e){note.textContent=e.name==='AbortError'?'保存をキャンセルしました。再度保存できます。':'保存できませんでした：'+e.message}finally{busy=false;go.disabled=cancel.disabled=false}};d.addEventListener('cancel',e=>{e.preventDefault();if(!busy)finish()});d.append(title,list,note,go,cancel);document.body.append(d);d.showModal()});
}
