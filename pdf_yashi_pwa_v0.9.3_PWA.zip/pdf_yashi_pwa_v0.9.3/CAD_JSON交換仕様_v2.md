# YASHI_CAD_EXCHANGE version 2

PDF矢視 v0.9.3が出力するCAD交換JSON。version 1の既存フィールドを残し、sourcePdfを追加する。
1用途につき1つの.yashi-cad.json。PDFの外部ファイルは不要。写真台帳本文・サムネイルは含まない。

## 最上位

- format: "YASHI_CAD_EXCHANGE"
- version: 2
- projectId / projectName: 案件情報
- numberingMode: all / inspection12 / report / survey
- coordinates: 座標系を説明する既存文字列
- pages: 元図順の全ページ。矢視や番号がないページも省略しない
- sourcePdf: 以下のオブジェクト

```json
{
  "fileName": "元図.pdf",
  "mimeType": "application/pdf",
  "encoding": "base64",
  "pageCount": 3,
  "byteLength": 12345,
  "sha256": "64桁の小文字16進数",
  "data": "JVBERi0..."
}
```

dataはdata: URLではなくBase64本体。デコードするとアプリが保持する現在の元図PDFのバイト列になる。
ページ追加・削除・差し替え済みの場合は、その変更後のPDFを指す。矢視を描画した出力PDFではない。
fileNameは案件に保持するPDFファイル名。ページ追加等でファイル名は自動変更しない。
byteLengthとsha256はデコードしたPDF全体を対象にする。文字列Base64自体のハッシュではない。

## ページと矢視：既存構造を維持

pages[]: page（1始まり）、pdfBox、rotation、userUnit、style、arrows。
arrows[]: arrowId、photoId、number、center、lineStart、tip、headLeft、headRight、circleRadius、lineWidth、fontSize、normalized、clockwiseAngleRadians。
numberは選択用途の番号。未リンクや用途番号なしの場合はnull。矢視自体はCAD JSON内に残す。
geometryの座標はPDF user space（X右、Y上）。PDFページのrotation・CropBox情報に従って配置する。
用紙上mmへの換算は userUnit × 25.4 / 72。建物図面の実寸縮尺を自動推定するものではない。
normalizedは表示PDFページ上でX右・Y下の正規化座標、clockwiseAngleRadiansはその画面上で時計回りの角度。
ページ回転済みの表示座標とPDF user spaceを二重に回転させないこと。

移動した矢視はページ設定と異なる記号サイズを保持する場合がある。
CAD側で形状を復元するときはpage.styleだけで一括生成せず、各矢視のcircleRadius・lineWidth・fontSize・tip等を優先する。
番号文字は記号とは別要素として作成し、フォントサイズ変更で番号の値を書き換えない。

## 推奨する将来の取込手順

1. formatとversionを検証する。
2. sourcePdf.encodingがbase64、mimeTypeがapplication/pdfであることを確認。
3. dataをデコードし、byteLengthとsha256を検証する。
4. 復元したPDFのページ数とsourcePdf.pageCountおよびpages.lengthを照合する。
5. PDFページを順番に配置し、各ページの矢視と番号文字を配置する。

## 互換性

version 1にはsourcePdfが存在しない。既存フィールドの名前と意味は変更していない。
versionを厳密に1だけ許可する旧取込処理は、2の許可とsourcePdfの扱いを追加する必要がある。
今回Vectorworksスクリプトは変更していない。旧スクリプトがそのまま動くとは保証しない。

## .yashiの補足

案件データには必要時のみ矢視ごとのstyleOverrideを追加する。
length / line / circle / head / symbolScaleの一部または全てを保持。存在しなければ従来のページ設定を使用する。
このフィールドは矢視ID・photoIdとは独立し、写真情報を複製しない。
IndexedDBのDB名・バージョン・ストアは変更しない。旧案件は新規フィールドなしで読める。
