(() => {
 const panel=document.getElementById('pagePanel'),grip=document.getElementById('pageResize'),root=document.documentElement,key='pdf-yashi-page-sidebar-width';let desired=164;
 try{const n=Number(localStorage.getItem(key));if(n>=112)desired=n}catch{}
 function bounds(){const photo=parseFloat(getComputedStyle(root).getPropertyValue('--photos-width'))||174;return {min:112,max:Math.max(112,Math.min(480,innerWidth-photo-180))}}
 function apply(n){const {min,max}=bounds(),w=Math.round(Math.max(min,Math.min(max,n)));root.style.setProperty('--pages-width',w+'px');grip.setAttribute('aria-valuemin',min);grip.setAttribute('aria-valuemax',max);grip.setAttribute('aria-valuenow',w);window.dispatchEvent(new Event('yashi-pages-resized'));return w}
 function save(){try{localStorage.setItem(key,String(desired))}catch{}}
 let drag;grip.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();drag={id:e.pointerId,x:e.clientX,w:panel.getBoundingClientRect().width};grip.setPointerCapture(e.pointerId)});
 grip.addEventListener('pointermove',e=>{if(drag?.id===e.pointerId)desired=apply(drag.w+e.clientX-drag.x)});
 const end=e=>{if(drag?.id===e.pointerId){drag=null;save()}};for(const type of ['pointerup','pointercancel','lostpointercapture'])grip.addEventListener(type,end);
 grip.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();e.stopPropagation();const b=bounds();desired=apply(e.key==='Home'?b.min:e.key==='End'?b.max:panel.getBoundingClientRect().width+(e.key==='ArrowRight'?24:-24));save()});
 window.addEventListener('resize',()=>apply(desired));window.addEventListener('yashi-photos-resized',()=>{const b=bounds();if(panel.getBoundingClientRect().width>b.max)apply(desired)});apply(desired);
})();
