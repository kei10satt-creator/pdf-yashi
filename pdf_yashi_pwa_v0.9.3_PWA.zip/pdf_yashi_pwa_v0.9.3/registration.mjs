// Coordinates are in the rendered (rotated/cropped) PDF viewport, at scale 1.7.
export const VIEW_SCALE=1.7;
export function similarity(oldPoints,newPoints){
 if(oldPoints.length!==2||newPoints.length!==2)throw Error('旧図・新図でそれぞれ2点を指定してください');
 const [p,q]=oldPoints,[u,v]=newPoints,dx=q.x-p.x,dy=q.y-p.y,ex=v.x-u.x,ey=v.y-u.y,l=dx*dx+dy*dy;
 if(![p,q,u,v].every(t=>Number.isFinite(t.x)&&Number.isFinite(t.y))||l<1||ex*ex+ey*ey<1)throw Error('基準点を離して2点指定してください');
 const a=(dx*ex+dy*ey)/l,b=(dx*ey-dy*ex)/l;return {a,b,tx:u.x-a*p.x+b*p.y,ty:u.y-b*p.x-a*p.y};
}
export function point(t,p){return{x:t.a*p.x-t.b*p.y+t.tx,y:t.b*p.x+t.a*p.y+t.ty}}
export function adjust(t,{percent=100,degrees=0,x=0,y=0}={},anchor={x:0,y:0}){
 if(![percent,degrees,x,y].every(Number.isFinite)||percent<=0)throw Error('縮尺は正の数、位置・角度は数値を指定してください');
 const r=degrees*Math.PI/180,k=percent/100,c=k*Math.cos(r),s=k*Math.sin(r);
 return{a:c*t.a-s*t.b,b:s*t.a+c*t.b,tx:anchor.x+c*(t.tx-anchor.x)-s*(t.ty-anchor.y)+x,ty:anchor.y+s*(t.tx-anchor.x)+c*(t.ty-anchor.y)+y};
}
export function symbolStyle(s){const k=s.symbolScale||1;return {...s,length:s.length*k,line:s.line*k,circle:s.circle*k,head:s.head*k,fontSize:Math.max(8,s.circle*1.35)*k,textWidth:Math.max(8,s.circle*1.65)*k}}
export function transformPage(arrows,oldSize,newSize,t,target){const angle=Math.atan2(t.b,t.a);return arrows.map(a=>{const p=point(t,{x:a.x*oldSize.width,y:a.y*oldSize.height});return {...a,page:target,x:p.x/newSize.width,y:p.y/newSize.height,angle:a.angle+angle}})}
export function buildPlacement(source,mappings,newSizes,oldSizes){
 const arrows=[],styles={},used=new Set();let outside=0;
 for(const m of mappings){if(!Number.isInteger(m.target)||!newSizes[m.target])throw Error('ページの対応先を確認してください');if(used.has(m.target))throw Error('同じ新ページへ複数の旧ページは指定できません');used.add(m.target);
   const t=m.transform;if(!t||![t.a,t.b,t.tx,t.ty].every(Number.isFinite)||Math.hypot(t.a,t.b)<1e-6)throw Error('すべての対応ページで位置合わせを確認してください');
   const converted=transformPage(source.arrows.filter(a=>(a.page||1)===m.old),oldSizes[m.old],newSizes[m.target],t,m.target);
   for(const a of converted)if(a.styleOverride&&m.scaleSymbols){a.styleOverride={...a.styleOverride,symbolScale:(arrowStyle(a,{...source.style,...source.pageStyles?.[m.old]}).symbolScale||1)*Math.hypot(t.a,t.b)};if(a.styleOverride.symbolScale<.01||a.styleOverride.symbolScale>100)throw Error('記号の表示倍率は0.01～100倍にしてください。')}
   outside+=converted.filter(a=>a.x<0||a.x>1||a.y<0||a.y>1).length;arrows.push(...converted);
   const style={...source.style,...source.pageStyles?.[m.old]},k=m.scaleSymbols?Math.hypot(t.a,t.b):1;
   style.symbolScale=(style.symbolScale||1)*k;if(style.symbolScale<.01||style.symbolScale>100)throw Error('記号の表示倍率は0.01～100倍の範囲にしてください');styles[m.target]=style;
 }
 if(arrows.length!==source.arrows.length)throw Error('対応していない矢視があります。旧ページの対応関係を確認してください');
 return {arrows,pageStyles:styles,outside};
}

export function styleOverride(value){if(!value||typeof value!=='object')return undefined;const out={};for(const [k,min,max] of [['length',30,180],['line',1,8],['circle',5,30],['head',5,30],['symbolScale',.01,100]])if(Number.isFinite(value[k]))out[k]=Math.max(min,Math.min(max,value[k]));return Object.keys(out).length?out:undefined}
export function arrowStyle(a,base){return {...base,...styleOverride(a?.styleOverride)}}
export function movePageArrows(source,from,to,oldSize,newSize,t,scaleSymbols=false){
 if(!Number.isInteger(from)||!Number.isInteger(to)||from===to||!oldSize||!newSize)throw Error('異なる移動元・移動先ページを指定してください。');
 if(!t||![t.a,t.b,t.tx,t.ty].every(Number.isFinite)||Math.hypot(t.a,t.b)<1e-6)throw Error('位置合わせを確認してください。');
 const targets=source.arrows.filter(a=>(a.page||1)===from);if(!targets.length)throw Error('移動元ページに矢視がありません。');
 const moved=transformPage(targets,oldSize,newSize,t,to).map(a=>{const style=arrowStyle(a,{...source.style,...source.pageStyles?.[from]});style.symbolScale=(style.symbolScale||1)*(scaleSymbols?Math.hypot(t.a,t.b):1);if(style.symbolScale<.01||style.symbolScale>100)throw Error('記号の表示倍率は0.01～100倍にしてください。');return {...a,styleOverride:styleOverride(style)}});
 return {...source,arrows:[...source.arrows.filter(a=>(a.page||1)!==from),...moved],currentPage:to};
}
