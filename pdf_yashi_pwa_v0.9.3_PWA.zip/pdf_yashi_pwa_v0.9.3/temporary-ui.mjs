import {isUnexported,recentGroups} from './project-state.mjs';
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n};
const btn=(text,fn)=>{const n=el('button',text);n.onclick=()=>Promise.resolve().then(fn).catch(e=>alert(e.message));return n};
export function mountTemporary(hooks){let epoch=0,allEpoch=0;
 function row(d,warning=false){const n=el('div',null,'tempRow');n.dataset.projectId=d.projectId;const info=el('div',null,'tempInfo'),dirty=isUnexported(d);info.append(el('strong',d.name||'無題'));
   info.append(el('div',dirty?'未書き出し':'書き出し済 '+new Date(d.exportedAt).toLocaleString(),'exportState '+(dirty?'unexported':'exported')));
   if(d.projectId===hooks.lastClosed()){n.classList.add('justClosed');info.append(el('small','直前まで作業していた案件'))}
   n.append(info,btn('開く',async()=>{document.getElementById('fileListModal').classList.add('hidden');await hooks.open(d.projectId)}),btn('書き出す',()=>hooks.export(d)));
   if(warning)n.append(btn('今後表示しない',async()=>{await hooks.update(d.projectId,x=>({...x,hideUnexportedWarning:true}));await refresh()}));
   return n;
 }
 async function refresh(){const ticket=++epoch,groups=recentGroups(await hooks.all(),hooks.lastClosed());if(ticket!==epoch)return;
   const recent=document.getElementById('recent'),older=document.getElementById('olderWarnings');recent.replaceChildren();older.replaceChildren();
   for(const d of groups.recent)recent.append(row(d));if(!groups.recent.length)recent.append(el('p','継続・一時保存データはまだありません。','hint'));
   if(groups.older.length){older.append(el('h3','その他の未書き出しデータ'));for(const d of groups.older)older.append(row(d,true))}
 }
 async function showAll(){const modal=document.getElementById('fileListModal'),list=document.getElementById('fileList');modal.classList.remove('hidden');document.getElementById('fileListTitle').textContent='継続・一時保存データの全一覧';const ticket=++allEpoch,rows=recentGroups(await hooks.all(),hooks.lastClosed()).all;if(ticket!==allEpoch)return;list.replaceChildren();
   if(!rows.length)list.append(el('p','保存データはまだありません。'));
   for(const d of rows){const n=row(d);if(d.hideUnexportedWarning)n.append(btn('未書き出し警告を再表示',async()=>{await hooks.update(d.projectId,x=>({...x,hideUnexportedWarning:false}));await refresh();await showAll()}));list.append(n)}
 }
 return {refresh,showAll};
}
// Prepare the Blob first. The explicit save button invokes the native picker/share API
// directly within its user gesture, including on iPad.
export function exportDialog(blob,name,save){return new Promise(resolve=>{
 const modal=el('dialog',null,'nativeExport'),title=el('h3','案件ファイルを書き出す'),note=el('p','iPadでは共有画面の「ファイルに保存」からBox等を選び、保存を完了してください。書き出し済みは標準保存機能への引き渡しを表し、Boxへのアップロード完了を表すものではありません。');
 modal.append(title,el('p',name),note);let done=false;
 const finish=ok=>{if(done)return;done=true;modal.close();modal.remove();resolve(ok)};
 const cancel=btn('キャンセル',()=>finish(false));const button=el('button','保存先を選んで書き出す');
 button.onclick=async()=>{button.disabled=true;cancel.disabled=true;try{const kind=await save(blob,name);if(kind==='downloaded'){note.textContent='ダウンロード先でファイルを確認してください。確認できたら「保存を確認しました」を押してください。';button.remove();modal.append(btn('保存を確認しました',()=>finish(true)));cancel.disabled=false}else finish(true)}catch(e){if(e?.name!=='AbortError')note.textContent='書き出せませんでした：'+e.message;button.disabled=false;cancel.disabled=false}};
 modal.append(button,cancel);modal.addEventListener('cancel',e=>{e.preventDefault();if(!cancel.disabled)finish(false)});document.body.append(modal);modal.showModal();
})}
