# PDF矢視アプリ → Vectorworks CAD交換JSON仕様

実装版：PDF矢視 v0.9.5。交換コンテナ：`YASHI_CAD_EXCHANGE` / `version: 2`。
追加シンボル仕様：`vectorworksSymbol.schemaVersion: 1`。

この文書と付属の確認用JSONは、Vectorworks 2020側のプラグイン開発へ渡すための仕様である。今回Vectorworksプラグインは実装していない。将来の取込に必要な元図PDF・形状・番号・番号フォントを1つのJSONに内包する。

v0.9.5ではpages[].pageIdを追加。連携用の案件IDも端末間で保持する。詳細は末尾の第11節。

## 1. 互換性と全体構造

v0.9.3の出力コードと実際に生成したversion 2 JSONを確認して追加実装した。コンテナversionは2のまま、既存フィールドの名称・値・意味を維持し、未知フィールドを無視する旧リーダーへの影響を抑えた。新プラグインはコンテナとシンボル仕様の両方のバージョンを検証する。

```text
format: "YASHI_CAD_EXCHANGE"
version: 2
projectId, projectName
numberingMode: "all" | "inspection12" | "report" | "survey"
coordinates: 既存のPDF座標説明文
sourcePdf: {fileName, mimeType, encoding, pageCount, byteLength, sha256, data}
vectorworksSymbol:
  schemaVersion: 1
  name: "YASHI_Arrow"
  sizeMode: "paper"
  unit: "mm-paper"
  referenceRendering: "exported PDF"
  localAxes: ローカル座標の説明
  definitions: [共通形状定義, ...]
  numberText: {independentOfSymbolRotation, color, font, fontSizeMeaning,
               fit, baseline, licenseFile, licenseText, licenseNotice}
pages: [
  {page, pageId, pdfBox, rotation, userUnit, style,
   paperCoordinates: {unit, origin, xDirection, yDirection,
                      pdfToPaper, width, height, normalized},
   arrows: [既存の矢視フィールド + vectorworks]}
]
```

1回のCAD出力は1用途。全ページを元PDF順で保持し、該当写真がないページも省略しない。全写真用と12条用等を同時に1ファイルへ詰める形式ではない。必要な用途を指定して書き出す。写真画像や説明、写真台帳本体は含めない。

旧version 1は元PDFを内包しない。version 2でもv0.9.3にはvectorworksSymbolがない。新仕様の取込でそれらを検出したら、この版以降での再出力を案内する。仕様未対応時に既存のVectorworks矢視シンボルへ黙って置き換えない。

## 2. sourcePdf：元PDFの復元

|フィールド|意味|
|---|---|
|fileName|案件内に保持する元PDFファイル名。ページ編集後にも元の名称を保持する場合がある|
|mimeType|`application/pdf`|
|encoding|`base64`|
|pageCount|現在の元PDFの全ページ数|
|byteLength|デコードしたPDFのバイト数|
|sha256|デコードしたPDF全体のSHA-256、小文字16進64桁|
|data|data URL接頭辞を含まないBase64本体|

Base64をデコードし、長さとSHA-256を検証してPDFとして保存する。元図へ矢視を描き込んだ出力PDFではなく、アプリが現在保持している矢視なしの元図バイト列である。ページ追加・削除・差し替え後は、その変更後のPDFを指す。

復元後のPDFページ数、sourcePdf.pageCount、pages.lengthが一致することを確認する。fileNameは実行する命令や任意の保存パスではない。取込側で安全なファイル名へ整理して一時領域へ保存し、同名既存ファイルを無断で上書きしない。

## 3. 既存のページ・矢視情報

`pages[].page`は1始まりのPDF物理ページ番号。所属はarrowsの親ページで確定する。

`pdfBox = [xMin,yMin,xMax,yMax]`はPDF.jsが使用した表示範囲（有効なCropBoxとMediaBoxの関係を反映）。0始まりとは限らない。
`rotation`はPDFページの表示回転、時計回りの度数（0/90/180/270）。`userUnit`はPDF座標1単位あたりの1/72インチの倍率。
`style`は従来のアプリ描画用パラメータ。紙面mmではない。すでにsymbolScaleを反映したlength/line/circle/head/fontSize/textWidthを含むため、symbolScaleを二重に掛けない。ページ間移動の個別調整がある場合、ページstyleだけでは各矢視を再現できない。

以下の既存矢視フィールドはすべて維持する。

|フィールド|定義|
|---|---|
|arrowId|矢視の永続ID。再取込・更新の照合に使う。番号から生成し直さない|
|photoId|写真台帳の共通識別子。未リンクはnull。矢視IDとは別物|
|number|選択用途の写真番号。番号なしはnull。数値を文字として表示し、再採番しない|
|center|丸の中心、回転適用前のPDF user-space座標|
|lineStart, tip|矢印線の始点と先端、同じPDF座標系|
|headLeft, headRight|矢尻三角形の残り2頂点、同じPDF座標系|
|circleRadius, lineWidth, fontSize|従来のPDF user-space上の円半径・線幅・最大emサイズ|
|normalized|表示回転後の描画領域での正規化位置、左上原点・X右・Y下|
|clockwiseAngleRadians|表示画面上の+Xから時計回りのラジアン角度|

番号なしの矢視も情報保全のためJSONへ残す。`vectorworks.visible`がfalseなら出力PDFに合わせる通常取込では描画しない。利用者が別途「番号なしも取り込む」を選ぶ機能を追加する場合のみ、その意図を明示して扱う。

arrowIdはこのアプリの矢視作成時に発行され、今回の出力では変更しない。再取込で保持する識別キーは通常 `(projectId, arrowId)`。コピー案件は別projectIdでも元矢視IDを引き継ぐことがあるため、全案件でarrowIdだけを一意と仮定しない。photoIdは複数の図面・矢視に現れる可能性があり、シンボル更新の主キーにしない。

## 4. PDF座標から紙面座標への変換

既存のcenter等は、ページrotationを適用する前のPDF座標。原点はPDF固有の(0,0)、X右・Y上で、pdfBoxの左下とは限らない。

新しい`paperCoordinates`は、表示回転・表示範囲・UserUnitを適用した、見えている用紙左下を(0,0)とする座標系。X右、Y上、単位mm-paper。width/heightは表示後の紙面寸法。丸め前のPDF表示寸法を使用し、画面canvasの整数丸め寸法とは区別する。

`pdfToPaper = [a,b,c,d,e,f]`は以下のアフィン変換。並び順を取り違えないこと。

```text
Xpaper = a * Xpdf + c * Ypdf + e
Ypaper = b * Xpdf + d * Ypdf + f
```

`k = userUnit * 25.4 / 72`、pdfBox=[x0,y0,x1,y1]とすると行列は以下。

|rotation|pdfToPaper|
|---|---|
|0|[k,0,0,k,-x0*k,-y0*k]|
|90|[0,-k,k,0,-y0*k,x1*k]|
|180|[-k,0,0,-k,x1*k,y1*k]|
|270|[0,k,-k,0,y1*k,-x0*k]|

この行列を使った後にrotationやuserUnitを再適用しない。

normalizedはPDF.js viewportをscale=1.7で取得し、width/heightをそれぞれ切り上げたcanvas上の位置を割ったもの。`paperCoordinates.normalized`にその整数width/heightとviewportScaleを保持する。画面点は `(normalized.x * width, normalized.y * height)`。旧正規化位置に紙面寸法を単純に掛けると端数分ずれるため、正確な取込はcenter＋行列、または次節のvectorworks.positionを使う。用紙外の矢視ではnormalizedが0〜1外になることもある。

特殊なUserUnitのPDFでも、既存のcircleRadius等および端点はそのまま維持している。v0.9.3は円・線幅・文字と端点の寸法換算に差があるため、これを今回勝手に補正しない。新しい共通形状は既存の実際のPDF幾何から算出し、画面もそのPDF表示へ合わせている。styleの値からの独自再換算を避けること。

## 5. vectorworksSymbol：共通の記号仕様

最上位のunitは`mm-paper`、sizeModeは`paper`。紙面mmとは、その用紙を100%・原寸で印刷した際のmm。画面のCSS pxや図面の実寸mmではない。プリンターの「用紙に合わせる」等による拡大縮小は仕様外。

共通パラメータを最上位に1組だけ置くと、ページ別設定や個別矢視調整を表せない。このため実際の寸法が等しい矢視をまとめた`definitions[]`を持たせ、矢視からsymbolRefで参照する。100個の同じ寸法の矢視なら1定義。位置・向き・番号の違いで定義を増やさない。寸法値はアプリの既存のPDF出力幾何から算出し、図形ローカル座標への変換時の浮動小数誤差だけを12桁精度へ正規化する。

各定義のローカル原点は丸の中心。+Xが矢印先端方向、+Yは+Xに向かって左。長さ・座標はすべてmm-paper。

|definitions[]内|内容|
|---|---|
|id|このJSON内の共通定義キー（shape-1等）。ファイルをまたぐ永続IDではない|
|circleDiameter|円径|
|arrowLength|丸中心から先端までの距離。円の端からの長さではない|
|arrowHeadSize|先端から矢尻の片側頂点までの斜辺長|
|lineWidth|円と矢印軸に共通の線幅|
|fontSize|番号文字の最大emサイズ。実際のサイズは各矢視labelを使う|
|textWidth|番号文字の最大許容幅。円半径×1.65|
|circle|center=[0,0]、radius、fill=null（塗りなし）|
|shaft|startとend。円との接続位置を含め、これらの点を直線で結ぶ|
|head|points=[先端,左,右]の閉じた三角形。fill=true、輪郭線なし|
|strokeColor|RGB 0〜1、通常表示の赤。軸・円・矢尻に適用|
|lineCap|`butt`（軸の端を伸ばさない）|
|lineJoin|`miter`|

circle/shaft/headを描画する値を正本とし、circleDiameter等は同じ値から生成した便利用パラメータ。受け手が双方を別々に編集・保存する二重管理はしない。既存styleと旧矢視フィールドは互換性のため残すが、VW新規描画はこの紙面mm仕様を使う。

基本名はYASHI_Arrow。1定義ならこの名前、複数ならYASHI_Arrowに識別用の接尾辞を付ける等、取込側が衝突を避ける。既存ユーザー作成シンボルを名前だけで上書きしない。再取込時の定義再利用はdefinitionの実内容で判定し、shape-1という番号だけで以前のファイルと同一視しない。

矢視が0件の場合はdefinitionsが空配列になる。PDFだけの案件として有効。

## 6. 各矢視の追加vectorworks情報

```text
vectorworks:
  symbolRef: definitions[].idへの参照
  position: [紙面左下基準X, Y]（mm-paper）
  rotationRadians: 紙面+Xから反時計回り
  visible: number !== null
  label: null または
    text: 番号の文字列
    fontSize: 実際に使用するemサイズ（mm-paper）
    width: 実際の文字列の送り幅（mm-paper）
    baseline: 丸中心から文字列左端ベースラインへのオフセット [dx,dy]
    rotationRadians: 0
```

positionはcenterにpdfToPaperを適用したもの。rotationRadiansは同様に変換したtip-centerのatan2で、clockwiseAngleRadiansとは正方向が逆。角度はラジアンで、degreeへ変換する場合は180/πを掛ける。

記号形状をrotationRadiansで回してpositionへ平行移動する。番号文字は記号と別要素で、用紙上で水平のままにする。label.baselineを矢視の回転で回さない。
textの番号値を維持し、フォントサイズや矢視形状を編集しても再採番しない。記号インスタンスと番号文字には、同じprojectId/arrowIdで対応を記録できる。photoIdは補助情報として保持する。

## 7. 番号フォントと文字の再現

画面・PDF・JSONは同じ同梱Liberation Sans Boldの実フォントデータから文字幅を計算する。出力PDFにも同じTrueTypeを埋め込む。v0.9.3のHelvetica Bold指定は環境によって代替フォントになるため、この版でそのPDF表示用代替フォントを明示的に共通化した。番号は写真台帳仕様どおり正の安全な整数（数字0〜9の組み合わせ）である。

numberText.fontにTrueTypeのBase64、SHA-256、MIME、ファイル名、ファミリー、PostScript名、太さを保持する。外部のフォントダウンロードは不要。licenseTextに同梱ライセンス全文を入れている。抽出・再配布時はライセンスも保持する。

取込側は、このフォントを利用可能にしてからネイティブ番号文字を作成する。利用できない場合は明示して処理を中断するか、利用者に代替の見た目を説明する。任意の端末標準フォントへ黙って置き換えると一致しない。フォントの登録方法はVW側の実装範囲で、JSON自体がOSへ登録するものではない。

フォント内の実送り幅をW（em単位）、最大サイズをF、円半径をRとすると、実サイズは `min(F, R*1.65/W)`。縦横を同じ倍率で縮小し、横だけ潰さない。左端ベースラインは中心から `[-実幅/2, -実サイズ*0.35]`。実数値はlabelに出力済みで、プラグインがアプリの式を再実装する必要はない。

フォントサイズの単位はポイントではなくemの紙面mm。ポイント相当は `mm * 72/25.4`。行高さ・文字の黒い部分の高さとは異なる。VWのテキスト配置基準が上端・中央等の場合は、そのAPIの基準をベースラインに合わせる。文字を矢視のシンボル定義内へ固定しない。

編集時だけの青い選択表示、選択ハンドル、未採番の操作用矢視は印刷デザインに含めない。字形の輪郭や配置は統一しても、各OS・描画エンジンのアンチエイリアスによる微小な違いはあり得る。

## 8. Vectorworksでの縮尺と配置

ページごとの取込チェック・レイヤ名・縮尺1/SはVectorworksの初回取込画面で指定する。JSONはSを推測・保存しない。例えば各ページを撮影位置図-01、-02…のデザインレイヤへ配置する。クラス名も取込側が管理する。

レイヤ上の実寸単位がmmの場合の一貫した処理例：

1. 復元PDFの該当ページを、pdfBoxの表示範囲・rotation・userUnitを反映して取り込む。
2. 表示後の左下をユーザー原点(0,0)へ合わせ、紙面width×S、height×Sの実寸へ配置する。
3. レイヤ縮尺を1/Sへ設定する。
4. 矢視中心を `position * S` の実寸へ置く。
5. 紙面mmで作った共通シンボルにインスタンス倍率Sを与える等、形状の印刷寸法がdefinitionsのmm値になるようにする。
6. 番号文字を別要素で水平に配置。中心・baselineの紙面座標をS倍して実寸配置し、フォントの印刷時emサイズをlabel.fontSizeへ合わせる。
7. arrowId/photoId/numberと案件・ページ識別を保持する。

**記号を印刷上もS倍にするという意味ではない。** 実寸のシンボル寸法を紙面寸法×Sにすると、レイヤ1/Sで印刷した際には元の紙面mmへ戻る。VW APIが紙面基準の文字サイズや線幅を受け取る場合は、Sを二重適用しない。線幅は通常の紙面線幅としてlineWidthを渡し、記号の拡大時にもその印刷幅を維持する。VWの内部単位への換算はプラグイン側で行う。

PDF配置APIがページ回転・UserUnitを自動適用する場合は、もう一度回転・拡大しない。実際の表示されたPDFの左下と寸法を確かめて登録する。既存ユーザー原点を変更する際のファイル全体への影響はVW側で管理し、ページ単位のローカル基準と混同しない。

## 9. 必須の取込検証と更新

- format/version/schemaVersionと単位が対応範囲か確認。
- PDF・フォントのBase64をデコードしてハッシュとPDF長を確認。
- PDFページ数・pages.pageの順序、必要フィールドの有限数値、symbolRef参照先を確認。
- プラグインが扱えない仕様なら誤った図形を作らず理由を表示。
- number=nullは「番号0」や空文字番号とは違う。通常はその矢視を非表示。
- 取り込んだ写真番号の振り直しやphotoIdの生成は行わない。
- 再取込時の同一矢視はprojectId/arrowIdで照合する。用途の違うJSONで同じ矢視が異なるnumber/visibleになることを考慮する。
- JSONにない矢視を自動削除するか等の更新方針は、別途VWプラグインで利用者へ提示する。この仕様で無断削除を要求しない。

## 10. 確認用データと確認範囲

付属の「交換確認案件_全写真.yashi-cad.json」は実際のブラウザで、この版のexportModel→cadWithPdfを実行した合成検証案件。4ページ、矢視113件、形状定義4件。回転0/90/180/270、非ゼロかつ小数の表示範囲、UserUnit=2、個別形状、1〜6桁番号、未リンク矢視を含む。

同寸法・異なる向きの100矢視は1定義へ集約。元PDFのBase64復元とSHA-256、ページ数、ID、写真ID、番号、既存座標フィールドを検査。画面描画・出力PDFの再レンダリング・JSONだけからの再描画を比較し、2pxのアンチエイリアス許容範囲では全4ページで赤色図形の不一致なし。

Vectorworks実機取込とiPad実機Safariでの確認は未実施。隔離したEdgeで通常画面・タッチ相当操作・PWAオフライン動作を自動検証している。

## 11. v0.9.5追加：恒久ページID

CAD JSONの各 `pages[]` に `pageId` を追加する。コンテナversion=2、vectorworksSymbol.schemaVersion=1は維持する。形状仕様を変えず、ページ識別情報を追加する互換拡張である。

```json
{
  "projectId": "案件の連携用ID",
  "pages": [
    {"page": 1, "pageId": "page-恒久ID-A"},
    {"page": 2, "pageId": "page-恒久ID-B"}
  ]
}
```

これは識別部分だけの抜粋。実際は既存のpdfBox/rotation/userUnit/style/arrows等も残る。

`page`は現在のPDF内の1始まり番号、`pageId`はページの論理的な同一性を示す不透明な文字列。同じ案件内で重複しない。pageIdからページ番号を解析・生成しない。Vectorworks側でレイヤを識別・更新するときは `(projectId, pageId)` の組を使い、ページ番号やレイヤ名だけで照合しない。

### ID継承規則

|操作|pageIdの扱い|
|---|---|
|新規案件|案件内の全PDFページにIDを作成して保存|
|PDF末尾へページ追加|既存IDを保持。追加するページごとに新ID。同じPDFを2回追加しても別ID|
|ページ削除|削除対象IDだけ取り除く。後ろのページが繰り上がってもIDは維持|
|元図PDF差し替え|位置合わせ画面の旧ページ→新ページ対応に沿って旧IDを移す|
|新PDFで順序変更|例えば旧1→新3なら、新3に旧1のpageIdを付ける|
|旧ページを末尾に残す|追加して保持する旧ページへ、その旧pageIdを引き継ぐ|
|新PDFの対応しない新規ページ|新IDを発行|
|同じPDF内で矢視だけ移動|PDFページIDは一切移さない。矢視の所属先だけ変わる|
|新しいPDFへ載せ替えて別案件を作る|対応ページのpageIdは継承し、連携用projectIdは新しくする。元案件は保持|
|PDF更新を中止・保存失敗|元案件のページIDを変更しない|
|通常の保存・再起動・CAD再出力|保存済みIDをそのまま使う|

図面が同じかどうかを画像認識やページ番号から自動推測する方式ではない。**PDF更新画面で指定した対応関係を、同じ論理ページという利用者の指定として扱う。** 内容が全く別のページへ差し替えた場合でも、旧ページの対応先として指定すれば同じIDを引き継ぐ。新しい独立ページとして扱う場合はページ追加を使う。

現在のアプリにページ一覧をドラッグして並べ替える新しい操作は追加していない。新PDFとの対応付けでの順序変更を扱う。将来並べ替え操作を作る場合も、PDFの並べ替えと同時にpageIdsの順序を移し、IDを発行し直してはいけない。

### 案件保存形式と端末間の継承

IndexedDB、単独 `.yashi`、一括 `.yashi-all` の各案件に次を保存する。

- `pageIds`: PDFページ順の文字列配列。配列index 0がPDF1ページ。
- `cadProjectId`: 端末をまたいでも保持する連携用案件ID。

既存の端末内 `projectId` は保存領域の管理キーで、案件ファイルを開いた際に別の一時保存レコードを作るため、新しい値になる。既存の案件を上書きしない動作は維持する。

**CAD JSONの最上位projectIdには、このcadProjectIdを出力する。** したがって、iPadから .yashi を書き出してWindowsで開き直しても、CADに出力されるprojectId + pageIdは維持される。CAD JSONへcadProjectIdという別名フィールドを要求するものではない。

初回は既存案件のprojectIdをcadProjectIdへ引き継ぐ。旧 .yashi の取り込みも、そのファイル内のprojectIdを引き継いでから端末内管理IDを新規作成する。一括バックアップの復元でも同様。

「新しいPDFへ載せ替える」のコピー操作は別案件としてcadProjectIdも新規発行する。単に同じ .yashi をもう一度開く操作では、同じ図面の再取込・更新としてcadProjectIdを保持する。この違いをVW側で考慮する。

### 旧案件の初回移行

pageIdsがない旧案件は、読み込み時または案件書き出し時に補完して保存する。初回移行のIDは、連携用案件IDと移行時のページ番号からSHA-256で決定する。同じ旧ファイルを別端末で初めて開いても同じ結果になるための互換処理で、**その後はPDF編集のたびに再計算しない。** ページ編集後は保存されたIDを対応関係に沿って移す。

厳密な初回計算：UTF-8の `JSON.stringify(["YASHI_LEGACY_PAGE_V1", cadProjectId, 1始まりページ番号])` のSHA-256、小文字16進数の前に `page-` を付ける。新規追加ページは乱数UUIDに `page-` を付ける。受け手はこの形式に依存せず不透明なIDとして扱う。

ID補完だけで図面を編集した扱いにはしない。従来の「書き出し済み／未書き出し」は維持し、旧案件に新IDを付けたデータを他端末へ渡すときは新しい .yashi を書き出す。変更後のページID配列は保存内容の指紋に含め、実際のページ変更は従来どおり未書き出しになる。

pageIdsの件数不一致・重複・空IDは、意味の違うページへ誤って対応させないようエラーとする。CAD JSON出力でもページIDが欠けた状態を拒否する。保存データのDB名・DBバージョン・ストアは変更しない。

移行前の別々の旧ファイルについて「同じ案件IDなのにページ順や構成がすでに異なる」履歴は、自動復元できない。旧CAD JSONもpageIdを持たないため、最初の移行時にVW既存レイヤとの対応を確定する必要がある。その後の更新は本仕様のIDを正本にする。pageIdsを保存しないv0.9.4以前へ戻して編集するとID情報を失うため、この連携運用はv0.9.5以降で継続する。

### Vectorworks側への実装申し送り

レイヤの付属レコード等へCADのprojectId/pageIdを保存する。再取込時はこの組が同じレイヤを更新し、pageの変化は現在のPDF抽出ページ番号として扱う。ページ名・番号の変更だけで新規レイヤを作らない。未知pageIdは新規ページ。今回JSONにない旧pageIdのレイヤを自動削除するかは、別途利用者へ確認する取込方針にする。

矢視は従来どおりprojectId/arrowIdで照合し、所属ページは親pages[]のpageIdで管理する。矢視だけのページ間移動ではpageId自体は変わらず、該当arrowIdの所属先が変わる。
