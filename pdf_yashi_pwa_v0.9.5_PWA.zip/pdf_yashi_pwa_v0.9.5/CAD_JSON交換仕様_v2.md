# CAD交換JSON version 2

v0.9.5ではpages[].pageIdを追加。正式仕様は [Vectorworks_CAD交換JSON仕様.md](Vectorworks_CAD交換JSON仕様.md) を参照してください。
