﻿PDF矢視 v0.9.5

恒久ページID・端末間で維持するCAD案件IDを追加。はじめに.txtとVectorworks_CAD交換JSON仕様.mdを参照してください。
