import clip from './lib/polygon-clipping.mjs';
import {frameCorners} from './output-frame.mjs';
const closed=ps=>[...ps.map(p=>[...p]),[...ps[0]]];
const geometry=ps=>[[closed(ps)]];
const cached=new WeakMap();
export function finalMask(edits,frame){
 if(!edits)return[];
 const old=(edits.objects||[]).filter(o=>o.type==='maskGroup'),key=JSON.stringify([frame,edits.maskRegion,old]);
 const previous=cached.get(edits);if(previous?.key===key)return previous.value;
 const box=geometry(frameCorners(frame));let value=edits.maskRegion?.polygons||[];
 for(const o of old)for(const p of o.geometry.polygons){const poly=geometry(p.points),area=o.geometry.keep==='inside'?clip.difference(box,poly):poly;value=clip.union(value,area)}
 value=value.length?clip.intersection(value,box):[];cached.set(edits,{key,value});return value;
}
export function combineMask(region,points,operation,frame){
 const polygon=geometry(points),box=geometry(frameCorners(frame));
 return clip.intersection(operation==='subtract'?clip.difference(region,polygon):clip.union(region,polygon),box);
}
export function storeMask(edits,polygons){
 const ids=[...(edits.maskRegion?.sourceObjectIds||[]),...edits.objects.filter(o=>o.type==='maskGroup').map(o=>o.objectId)];
 edits.maskRegion={polygons,sourceObjectIds:[...new Set(ids)]};edits.objects=edits.objects.filter(o=>o.type!=='maskGroup');
}
export function maskPath(c,region){c.beginPath();for(const polygon of region)for(const ring of polygon){ring.forEach((p,i)=>i?c.lineTo(...p):c.moveTo(...p));c.closePath()}}
export function paintMask(c,region,{draft=false}={}){c.save();maskPath(c,region);c.fillStyle=draft?'rgba(95,110,125,.65)':'white';c.fill('evenodd');c.restore()}
export function maskHandles(region){const out=[];region.forEach((polygon,pi)=>polygon.forEach((ring,ri)=>{for(let i=0;i<ring.length-1;i++){const a=ring[i],b=ring[i+1];out.push({pi,ri,i,edge:false,p:a});out.push({pi,ri,i,edge:true,p:[(a[0]+b[0])/2,(a[1]+b[1])/2]})}}));return out}
export function moveMaskHandle(region,h,p){const n=structuredClone(region),r=n[h.pi][h.ri],last=r.length-1,i=h.i,j=(i+1)%last;if(h.edge){const a=r[i],b=r[j],dx=b[0]-a[0],dy=b[1]-a[1],len=dx*dx+dy*dy;const t=len?((p[0]-h.p[0])*(-dy)+(p[1]-h.p[1])*dx)/len:0;r[i]=[a[0]-dy*t,a[1]+dx*t];r[j]=[b[0]-dy*t,b[1]+dx*t]}else r[i]=p;r[last]=[...r[0]];return n}
export function normalizeMask(region,frame){return region.length?clip.intersection(clip.union(region),geometry(frameCorners(frame))):[]}
export function validateMask(region){if(!region||!Array.isArray(region.polygons)||!Array.isArray(region.sourceObjectIds)||!region.sourceObjectIds.every(s=>typeof s==='string'))throw Error('マスク領域の形式が不正です');for(const polygon of region.polygons){if(!Array.isArray(polygon)||!polygon.length)throw Error('マスク輪郭が不正です');for(const ring of polygon){if(!Array.isArray(ring)||ring.length<4||!ring.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))||ring[0][0]!==ring.at(-1)[0]||ring[0][1]!==ring.at(-1)[1])throw Error('マスク輪郭が閉じていません')}}}
