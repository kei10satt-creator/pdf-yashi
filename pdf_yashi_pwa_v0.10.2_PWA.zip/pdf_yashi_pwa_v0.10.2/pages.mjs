import {arrowRecord} from './photos.mjs';
// Stored coordinates are normalized independently for each PDF page.
export function pageOf(a) { return Number.isSafeInteger(a.page) && a.page > 0 ? a.page : 1; }
export function snapshotPages(stored, current, page, width, height) {
  if (!page) return stored.map(a=>({...a, page:pageOf(a)}));
  return [...stored.filter(a=>pageOf(a)!==page), ...current.map(a=>({...arrowRecord(a,width,height),page}))];
}
export function restorePage(records, page, width, height) {
  return records.filter(a=>pageOf(a)===page).map(a=>({...arrowRecord(a),x:a.x*width,y:a.y*height,page}));
}
