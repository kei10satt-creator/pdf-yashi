# PDF矢視 v0.10.2 — CAD交換JSON pageEdits追加仕様

本書はVectorworks_CAD交換JSON仕様.mdのpageEditsに関する追加・更新定義です。新マスクについては本書を優先してください。
YASHI_CAD_EXCHANGE.version=2、vectorworksSymbol.schemaVersion=1を維持します。projectId、pages[].pageId、矢視・写真ID、番号、元PDF、従来座標・スタイルの変更はありません。sourcePdf.dataは元PDFのバイト列のままです。

## 構造

pageEditsは.yashi、内部保存、CAD JSONで同じ構造です。新規編集ではschemaVersion 3。未編集の旧schemaVersion 1/2は保持し、読込可能です。非対応の取込側は拡張を無視して完成図を再現できると扱わず、対応が必要なことを表示してください。

~~~json
{"pageEdits":{"schemaVersion":3,"unit":"mm-paper","coordinates":"displayed page top-left; +X right; +Y down; after PDF rotation; before pdfTransform","pages":{"pageId":{"pdfTransform":[1,0,0,1,0,0],"outputFrame":{"paperSize":"A3","orientation":"landscape","x":0,"y":0,"width":420,"height":297},"objects":[],"maskRegion":{"polygons":[[[[10,10],[50,10],[50,50],[10,50],[10,10]],[[20,20],[20,30],[30,30],[30,20],[20,20]]]],"sourceObjectIds":[]}}}}}
~~~

pagesのキーは恒久pageIdです。未登録ページには編集なし。outputFrame、maskRegionは省略可能です。

## 座標系・単位

元PDFのCropBox・Rotate・UserUnitを反映した表示ページ左上を(0,0)、右を+X、下を+Yとした紙面mmです。pdfTransform適用前の固定座標系です。元ページ寸法はpages[].paperCoordinates.width/heightから取得できます。矢視の従来PDF user-space座標は変更しません。
既存pdfToPaperをB、元ページ表示高さをH、F=[1,0,0,-1,0,H]としてD=F×BがPDF user-spaceから本座標系への変換です。
pdfTransform=[a,b,c,d,e,f]はx'=a*x+c*y+e、y'=b*x+d*y+f。a,b,c,dは無次元、e,fは紙面mm。元PDFだけに適用する相似変換です。PDF raw座標へ適用する行列はinverse(D)×pdfTransform×D。作図・矢視・マスク・出力枠へ重ねて適用しません。

## 出力枠

outputFrame.paperSizeはoriginal/A3/A4、orientationはportrait/landscape、x/yは左上、width/heightは紙面mm。A3は297×420、A4は210×297で縦横を反映。省略時は元ページの位置(0,0)・表示寸法です。負のx/yも可能です。
最終出力の範囲はこの矩形です。枠移動で各矢視・図形・マスクの座標を書き換えません。PDF出力は四隅をinverse(D)でraw座標へ戻した境界をMediaBox/CropBox等に設定し、元Rotate/UserUnitを維持します。元PDFの元CropBoxからはみ出す内容は表示しません。
取込側で元図左下原点を維持する場合、点(x,y)を(x,H-y)へ変換します。出力枠左下原点を使う場合は(x-outputFrame.x, outputFrame.y+outputFrame.height-y)。PDF・矢視・作図で同じ原点を使用してください。図面縮尺はVectorworks側で指定します。

## maskRegion（schemaVersion 3）

maskRegion.polygonsは閉じたリングによるMultiPolygon配列です。階層は[polygon[ring[point[x,y]]]]。各polygonの最初のringが外周、以降が穴です。先頭点と末尾点は同一です。polygons:[]はマスクなしです。輪郭を独立した白塗り図形として扱うと穴が消えるため、各polygonを穴付きの複合パスとして偶奇規則で白塗りしてください。線は描きません。複数polygonは和集合です。
結合と切り抜きの結果を計算済みの最終領域として保存します。操作履歴や独立した追加図形の羅列ではありません。切り抜きはマスクの解除で、元PDFを復元・再表示します。描画時には出力枠でクリップします。
sourceObjectIdsは旧maskGroupから変換した際のobjectIdの記録です。形状の管理単位や矢視IDではありません。新規マスクなら空配列です。通常のobjectsには最終マスクを重複して保存しません。

## 旧maskGroupとの互換

旧objects内のmaskGroup.geometry.polygonsはtype:rectangle/polygonとpointsを持ちます。keep:outsideまたは省略は輪郭内を隠し、keep:insideは出力枠内の輪郭外を隠します。複数輪郭はそれぞれ隠す領域の和集合です。
旧マスクは読込時の表示ではこのルールで合成します。PDFマスクで最初の変更を確定すると旧maskGroupをobjectsから除き、maskRegionへ変換します。元のobjectIdはsourceObjectIdsへ記録します。未編集・キャンセル時は元の保存構造を維持します。もし両形式がある場合は、それぞれの隠す領域を合成して表示します。

## 通常作図オブジェクト

各objects[]はobjectId、type、geometry、style、unit:mm-paperを持ちます。コピー以外はobjectIdを維持します。
- line：geometry.start/end、style.lineWidth
- rectangle：対角のgeometry.start/end、style.lineWidth
- polygon：geometry.points、style.lineWidth（末尾と先頭を結ぶ）
- circle：geometry.center/radius、style.lineWidth
- text：geometry.position/text、style.fontSize
通常図形は塗りなし、#111111、butt線端、miter結合。文字は左側ベースライン起点、横書き1行、通常sans-serif。fontSizeはem高さの紙面mm、pt=mm×72/25.4です。実際の書体は実行端末に依存し、作図用フォントは内包しません。出力PDFでは追加文字を600dpi画像化しますが、JSONでは編集可能な文字列です。図面枠は普通の線・矩形・文字へ展開されています。

## 描画順・ページ更新

1. 元PDFを元CropBoxでクリップし、pdfTransformを適用
2. 最終マスク領域を白塗り（出力枠内だけ）
3. 通常の作図・文字をobjectsの配列順に描画
4. 既存矢視を従来の用途別番号ルールで描画
5. 全体をoutputFrameでクリップ
編集用グレー表示・青点線・選択ハンドルは出力しません。
PDF差し替えでは対応するpageIdを引き継ぎ、作図点とmaskRegionの全リングを位置合わせ変換します。outputFrameの数値はそのまま維持し、元PDFのpdfTransformは単位行列に戻します。旧ページを残す場合は全編集情報を保持します。削除ページの編集情報は削除、新規ページには編集情報なしです。
既存の通常図形の線幅・文字サイズは「記号サイズも変更」に応じて変換します。四角形を回転した場合はpolygonへ変換しますがIDは維持します。マスクは輪郭座標だけを変換します。

## 保存・取込側の注意

出力枠、最終マスク、矢視移動・削除は自動保存・fingerprint判定に含まれます。内部履歴は交換JSONには入れません。枠外矢視は自動削除しません。CAD JSONには枠外も含めた既存矢視情報が保持されるため、取込側で出力枠に応じた表示・印刷範囲を扱ってください。
元PDFの復元はsourcePdfのencodingに従ってBase64をデコードし、pageCount・SHA-256を確認します。従来の交換仕様と同じです。
Vectorworksプラグインは今回の成果物に含みません。

## 領域演算の実装

[polygon-clipping 0.15.7](https://github.com/mfogel/polygon-clipping)を同梱し、union/difference/intersectionで最終輪郭を生成しています。元配布UMDをES moduleから利用できるようラップしています。ライセンスと依存コードの通知はlib内に同梱しています。
