import {transferPageEdits,paintEditedPage} from "./drawing-update.mjs";
import {mapPageIdentity} from './page-identity.mjs';
import {prepareCanvasFont} from './number-font.mjs';
import {drawArrowSymbol} from './arrow-render.mjs';
import {PDFDocument} from './lib/pdf-lib.mjs';
import {similarity,adjust,point,buildPlacement,symbolStyle,arrowStyle,movePageArrows,VIEW_SCALE} from './registration.mjs';
const element=(tag,text)=>{const n=document.createElement(tag);if(text)n.textContent=text;return n};
const button=(text,fn)=>{const b=element('button',text);b.type='button';b.onclick=()=>Promise.resolve().then(fn).catch(e=>alert(e.message));return b};
const identity=()=>({a:1,b:0,tx:0,ty:0});
const MM=VIEW_SCALE*72/25.4;
export async function openPdfUpdate({source,pdfjs,commit,number}){
 const fontData=await prepareCanvasFont();
 const dialog=element('dialog');dialog.className='pdfUpdate';
 dialog.innerHTML='<h2>元図PDFの更新</h2><p>旧図の基準点1・2、新図の同じ位置の1・2を指定します。位置・縮尺・回転を合わせ、重ね合わせで確認してから確定してください。</p>';
 const mode=element('select');mode.setAttribute('aria-label','更新方法');for(const [value,label] of [['replace','元図PDFを差し替える'],['copy','新しいPDFへ載せ替える'],['move','同じPDF内で矢視を移動']]){const o=element('option',label);o.value=value;mode.append(o)}
 const name=element('input');name.value=source.name+'（載せ替え）';name.setAttribute('aria-label','新しい案件名');name.disabled=true;name.hidden=true;
 const file=element('input');file.type='file';file.accept='application/pdf';file.setAttribute('aria-label','新しい元図PDF');file.disabled=true;
 const moveFrom=element('select'),moveLabel=element('label','移動元ページ ');moveFrom.setAttribute('aria-label','移動元ページ');moveLabel.append(moveFrom);moveLabel.hidden=true;dialog.append(mode,name,moveLabel,file);mode.disabled=true;
 const status=element('p','元図を読み込み中…'),mapping=element('div'),workspace=element('div');workspace.className='registrationWorkspace';const top=element('div'),progress=element('span'),topApply=button('内容を確定',applyUpdate);top.className='registrationTop';progress.className='registrationProgress';progress.setAttribute('role','status');topApply.className='applyTop';top.append(topApply,progress);dialog.append(status,top,mapping,workspace);
 const sources=element('div');sources.className='registrationSources';const oldCanvas=element('canvas'),newCanvas=element('canvas'),overlay=element('canvas');
 for(const [label,canvas] of [['旧図：基準点1 → 2',oldCanvas],['新図：同じ位置の1 → 2',newCanvas]]){const section=element('section');section.append(element('h3',label));const shell=element('div');shell.className='registrationShell';shell.append(canvas);section.append(shell);sources.append(section)}
 workspace.append(sources);
 const controls=element('div');controls.className='registrationControls';
 const zoom=element('input');zoom.type='range';zoom.min='100';zoom.max='300';zoom.value='100';zoom.setAttribute('aria-label','基準点の表示拡大');zoom.oninput=()=>{oldCanvas.style.width=newCanvas.style.width=zoom.value+'%'};controls.append(element('label','基準点の表示拡大'),zoom);
 const fields={};for(const [key,label,value,step] of [['x','横移動（用紙上mm）',0,.1],['y','縦移動（用紙上mm・下が正）',0,.1],['degrees','回転の微調整（度・時計回り）',0,.1],['percent','縮尺の微調整（%）',100,.1]]){const l=element('label',label),input=element('input');input.type='number';input.value=value;input.step=step;input.setAttribute('aria-label',label);l.append(input);controls.append(l);fields[key]=input;input.oninput=()=>{const m=current();if(m){m.fine[key]=Number(input.value);m.confirmed=false;m.pending=true;preview();updateLabels()}}}
 const symbols=element('input');symbols.type='checkbox';const symLabel=element('label','記号の表示サイズも配置の縮尺に合わせる');symLabel.prepend(symbols);symbols.onchange=()=>{const m=current();if(m){m.scaleSymbols=symbols.checked;m.confirmed=false;m.pending=true;preview();updateLabels()}};controls.append(symLabel,element('p','チェックなし：丸・数字・矢印線は現在の表示サイズを維持します。配置位置と向きは常に変換します。'));
 workspace.append(controls,element('h3','重ね合わせプレビュー（新図＋位置合わせした旧図＋矢視）'));
 const opacity=element('input');opacity.type='range';opacity.min='0';opacity.max='100';opacity.value='35';opacity.setAttribute('aria-label','旧図の濃さ');opacity.oninput=preview;workspace.append(element('label','旧図の濃さ'),opacity,overlay);
 const detail=element('p');workspace.append(detail);
 const reset=button('このページの基準点をやり直す',()=>{const m=current();m.oldPoints=[];m.newPoints=[];m.confirmed=false;m.pending=true;preview();paintPins();updateLabels()});
 const confirmPage=button('このページの位置合わせを確認',()=>{completeCurrent();updateLabels()});workspace.append(reset,confirmPage);
 const footer=element('div');footer.className='registrationFooter';const apply=button('プレビューの内容で確定',applyUpdate),cancel=button('更新を中止',()=>finish(false));apply.disabled=topApply.disabled=true;footer.append(apply,cancel);dialog.append(footer);
 let oldDoc,newDoc,newBytes,newName,maps=[],oldSizes={},newSizes={},selected=1,oldImage,newImage,busy=false,closed=false,epoch=0,resolve;
 let previousMode='replace';const completed=new Promise(r=>resolve=r);const current=()=>maps.find(m=>m.old===selected);
 function finish(value){if(closed||busy)return;closed=true;epoch++;dialog.close();dialog.remove();oldDoc?.loadingTask.destroy().catch(console.warn);newDoc?.loadingTask.destroy().catch(console.warn);resolve(value)}
 dialog.addEventListener('cancel',e=>{e.preventDefault();finish(false)});document.body.append(dialog);dialog.showModal();workspace.hidden=true;
 const doc=bytes=>pdfjs.getDocument({data:new Uint8Array(bytes).slice(),cMapUrl:'./lib/cmaps/',cMapPacked:true,standardFontDataUrl:'./lib/standard_fonts/',wasmUrl:'./lib/wasm/',iccUrl:'./lib/iccs/'}).promise;
 async function sizes(d){const result={};for(let n=1;n<=d.numPages;n++){const p=await d.getPage(n),v=p.getViewport({scale:VIEW_SCALE});result[n]={width:Math.ceil(v.width),height:Math.ceil(v.height)}}return result}
 function matrix(){const m=current();return adjust(similarity(m.oldPoints,m.newPoints),{...m.fine,x:m.fine.x*MM,y:m.fine.y*MM},m.newPoints[0])}
 function isDone(m){return m.target==='keep'||!!m.target&&m.confirmed}
 function ready(){const targets=maps.filter(m=>m.target&&m.target!=='keep').map(m=>m.target);return maps.length&&maps.every(isDone)&&new Set(targets).size===targets.length}
 function updateLabels(){for(const row of mapping.children){const m=maps.find(x=>x.old===Number(row.dataset.old));if(!m)continue;const done=isDone(m);row.querySelector('select').value=m.target;row.querySelector('span').textContent=m.target==='keep'?'旧ページを追加して保持':m.confirmed?'位置合わせ確認済み':m.pending?'調整途中（保持中）':m.target?'位置合わせ未確認':'対応先を指定してください';const b=row.querySelector('button');b.textContent=done?'位置合わせ完了 ✓':'位置合わせ';b.classList.toggle('registrationDone',done);row.classList.toggle('mappingDone',done);b.disabled=busy;row.querySelector('select').disabled=busy}
  const count=maps.filter(isDone).length,targets=maps.filter(m=>m.target&&m.target!=='keep').map(m=>m.target);progress.textContent='確認済み '+count+'／'+maps.length+'ページ'+(new Set(targets).size!==targets.length?'：同じ新ページへの重複指定を変更してください':ready()?'：すべて完了しました':'：全ページの確認後に確定できます');
  apply.disabled=topApply.disabled=busy||!ready();apply.classList.toggle('registrationDone',!!ready());topApply.classList.toggle('registrationDone',!!ready());const m=current();confirmPage.textContent=m?.confirmed?'位置合わせ完了 ✓':'このページの位置合わせを確認';confirmPage.classList.toggle('registrationDone',!!m?.confirmed);let valid=!!oldImage&&!!newImage;try{matrix()}catch{valid=false}confirmPage.disabled=busy||!valid;reset.disabled=busy||!oldImage;for(const input of controls.querySelectorAll('input'))input.disabled=busy;mode.disabled=busy;moveFrom.disabled=busy;name.disabled=busy||mode.value!=='copy';
 }
 function completeCurrent(){const m=current();if(!m?.target||m.target==='keep')throw Error('対応先のページを指定してください。');m.transform=matrix();m.confirmed=true;m.pending=false}
 function clearMapping(m){m.target='';m.oldPoints=[];m.newPoints=[];m.fine={x:0,y:0,degrees:0,percent:100};m.scaleSymbols=false;m.confirmed=false;m.pending=false;delete m.transform}
 async function moveTo(n,target){if(busy||closed)return;const m=current();if(n!==selected&&m?.pending&&!m.confirmed){let valid=true;try{matrix()}catch{valid=false}const answer=await askMove(valid);if(answer==='stay')return;if(answer==='reset'){clearMapping(m);await show(m.old);updateLabels();return}if(answer==='complete')completeCurrent()}
  const next=maps.find(m=>m.old===n);if(target!==undefined&&next.target!==target){clearMapping(next);next.target=target}await show(n);updateLabels();
 }
 function askMove(valid){return new Promise(resolve=>{const d=element('dialog');d.className='registrationChoice';d.append(element('h3','このページの位置合わせを完了してから移動しますか？'),element('p','「完了しないで移動」は今回の調整を保持します。戻れば続きから作業できます。'));const warning=element('p','「キャンセル」はこのページの調整内容と対応先を破棄し、ページ指定からやり直します。');warning.className='choiceWarning';d.append(warning);if(!valid)d.append(element('p','基準点や入力値が未完成のため、まだ完了できません。'));const finish=answer=>{d.close();d.remove();resolve(answer)};const done=button('完了して移動',()=>finish('complete'));done.disabled=!valid;d.append(done,button('完了しないで移動',()=>finish('keep')),button('キャンセル',()=>finish('reset')));d.addEventListener('cancel',e=>{e.preventDefault();finish('stay')});document.body.append(d);d.showModal()})}

 async function imageOf(d,n){const p=await d.getPage(n),v=p.getViewport({scale:VIEW_SCALE}),c=element('canvas');c.userUnit=p.userUnit||1;c.width=Math.ceil(v.width);c.height=Math.ceil(v.height);await p.render({canvasContext:c.getContext('2d'),viewport:v}).promise;if(d===oldDoc)paintEditedPage(c,source.pageEdits?.pages?.[source.pageIds[n-1]]);return c}
 async function show(n){const ticket=++epoch;selected=n;oldImage=newImage=null;const m=current();workspace.hidden=m.target==='keep'||!m.target;confirmPage.disabled=true;reset.disabled=true;
   for(const row of mapping.children)row.classList.toggle('selectedMapping',Number(row.dataset.old)===n);
   if(!m.target){status.textContent='旧'+n+'ページの対応先を指定してください。';updateLabels();return}
   if(m.target==='keep'){status.textContent='旧'+n+'ページは新PDFの末尾にそのまま残します。矢視も保持します。';updateLabels();return}
   status.textContent='旧'+n+'ページ → 新'+m.target+'ページを表示中…';
   for(const key of Object.keys(fields))fields[key].value=m.fine[key];symbols.checked=m.scaleSymbols;
   const images=await Promise.all([imageOf(oldDoc,n),imageOf(newDoc,m.target)]);if(closed||ticket!==epoch)return;
   [oldImage,newImage]=images;for(const [canvas,img] of [[oldCanvas,oldImage],[newCanvas,newImage]]){canvas.width=img.width;canvas.height=img.height}
   overlay.width=newImage.width;overlay.height=newImage.height;status.textContent='旧'+n+'ページ → 新'+m.target+'ページ。基準点は離れた2点を選んでください。';reset.disabled=false;paintPins();preview();updateLabels();
 }
 function paintPins(){for(const [canvas,img,points] of [[oldCanvas,oldImage,current()?.oldPoints],[newCanvas,newImage,current()?.newPoints]]){if(!img)continue;const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.drawImage(img,0,0);for(const [i,p] of points.entries()){const radius=Math.max(12,canvas.width/65);c.fillStyle=i?'#dc7700':'#006bdf';c.beginPath();c.arc(p.x,p.y,radius,0,Math.PI*2);c.fill();c.font='bold '+radius*1.4+'px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillStyle='white';c.fillText(String(i+1),p.x,p.y)}}}
 for(const [canvas,key] of [[oldCanvas,'oldPoints'],[newCanvas,'newPoints']]){let start;canvas.addEventListener('pointerdown',e=>start={x:e.clientX,y:e.clientY});canvas.addEventListener('pointerup',e=>{if(!start||Math.hypot(e.clientX-start.x,e.clientY-start.y)>7||!oldImage||!newImage||busy)return;start=null;const r=canvas.getBoundingClientRect(),p={x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height},m=current();if(m[key].length===2)m[key]=[];m[key].push(p);m.confirmed=false;m.pending=true;paintPins();preview();updateLabels()});canvas.addEventListener('pointercancel',()=>start=null)}
 function preview(){if(!oldImage||!newImage)return;const c=overlay.getContext('2d');c.setTransform(1,0,0,1,0,0);c.clearRect(0,0,overlay.width,overlay.height);c.globalAlpha=1;c.drawImage(newImage,0,0);confirmPage.disabled=true;
   try{const t=matrix(),m=current(),ratio=Math.hypot(t.a,t.b);c.save();c.globalAlpha=Number(opacity.value)/100;c.transform(t.a,t.b,-t.b,t.a,t.tx,t.ty);c.drawImage(oldImage,0,0);c.restore();
     const base={...source.style,...source.pageStyles?.[m.old]},s=symbolStyle({...base,symbolScale:(base.symbolScale||1)*(m.scaleSymbols?ratio:1)});let outside=0;
     for(const a of source.arrows.filter(a=>(a.page||1)===m.old)){const p=point(t,{x:a.x*oldImage.width,y:a.y*oldImage.height}),angle=a.angle+Math.atan2(t.b,t.a);if(p.x<0||p.y<0||p.x>overlay.width||p.y>overlay.height)outside++;drawArrow(c,p,angle,symbolStyle({...arrowStyle(a,base),symbolScale:(arrowStyle(a,base).symbolScale||1)*(m.scaleSymbols?ratio:1)}),number(a),fontData,newImage.userUnit)}
     if(mode.value==='move'){c.save();c.globalAlpha=.45;for(const a of source.arrows.filter(a=>(a.page||1)===m.target))drawArrow(c,{x:a.x*newImage.width,y:a.y*newImage.height},a.angle,symbolStyle(arrowStyle(a,{...source.style,...source.pageStyles?.[m.target]})),number(a),fontData,newImage.userUnit);c.restore()}
     detail.textContent=(mode.value==='move'?'移動元の矢視を移します。移動先に元からある矢視は薄く表示。':'')+'配置の縮尺 '+(ratio*100).toFixed(3)+'% ／ 回転 '+(Math.atan2(t.b,t.a)*180/Math.PI).toFixed(3)+'°'+(outside?' ／ 用紙外の矢視 '+outside+'件':'')+'。確定後も選択モードで個別調整できます。';confirmPage.disabled=false;
   }catch(e){detail.textContent=e.message}
 }
 async function loadTarget(bytes,fileName){busy=true;file.disabled=true;updateLabels();try{const next=await doc(bytes),dimensions=await sizes(next);if(closed){await next.loadingTask.destroy();return}await newDoc?.loadingTask.destroy();newDoc=next;newBytes=bytes;newName=fileName;newSizes=dimensions;maps=Array.from({length:oldDoc.numPages},(_,i)=>({old:i+1,target:i<next.numPages?i+1:'keep',oldPoints:[],newPoints:[],fine:{x:0,y:0,degrees:0,percent:100},scaleSymbols:false,confirmed:false,pending:false}));if(mode.value==='move'){const from=Number(moveFrom.value),target=from===1?2:1;maps=[{old:from,target,oldPoints:[],newPoints:[],fine:{x:0,y:0,degrees:0,percent:100},scaleSymbols:false,confirmed:false,pending:false}]}mapping.replaceChildren();
     for(const m of maps){const row=element('div');row.className='mappingRow';row.dataset.old=m.old;const select=element('select');select.setAttribute('aria-label','旧'+m.old+'ページの対応先');const empty=element('option','対応先を選択');empty.value='';select.append(empty);for(let n=1;n<=next.numPages;n++){if(mode.value==='move'&&n===m.old)continue;const o=element('option','新'+n+'ページ');o.value=n;select.append(o)}const keep=element('option','旧ページを末尾に残す');keep.value='keep';if(mode.value!=='move')select.append(keep);select.value=m.target;select.onchange=()=>{const target=select.value==='keep'?'keep':select.value?Number(select.value):'';select.value=m.target;moveTo(m.old,target).catch(e=>status.textContent=e.message)};row.append(element('b','旧'+m.old+'ページ → '),select,element('span'),button('位置合わせ',()=>moveTo(m.old)));mapping.append(row)}
     busy=false;updateLabels();await show(maps[0].old);
   }catch(e){status.textContent='PDFを読み込めません：'+e.message}finally{busy=false;file.disabled=false;updateLabels()}}
 file.onchange=async()=>{const f=file.files[0];if(f)await loadTarget(new Uint8Array(await f.arrayBuffer()),f.name)};
 mode.onchange=async()=>{const next=mode.value,changing=(previousMode==='move')!==(next==='move');if(changing&&maps.some(m=>m.pending||m.confirmed)&&!confirm('更新方法を変えると、今回の位置合わせを初期化します。よろしいですか？')){mode.value=previousMode;return}previousMode=next;moveLabel.hidden=next!=='move';file.hidden=next==='move';name.disabled=next!=='copy';name.hidden=next!=='copy';dialog.querySelector('p').textContent=next==='move'?'同じPDFの移動元・移動先で同一位置を2点指定します。矢視だけを移動し、PDFページは残します。':'旧図の基準点1・2、新図の同じ位置の1・2を指定します。位置・縮尺・回転を合わせ、重ね合わせで確認してから確定してください。';const headings=sources.querySelectorAll('h3');headings[0].textContent=next==='move'?'移動元：基準点1 → 2':'旧図：基準点1 → 2';headings[1].textContent=next==='move'?'移動先：同じ位置の1 → 2':'新図：同じ位置の1 → 2';if(changing){maps=[];mapping.replaceChildren();workspace.hidden=true;file.value='';oldImage=newImage=null;if(next==='move')await loadTarget(source.pdfBytes,source.pdfFileName);else{await newDoc?.loadingTask.destroy();newDoc=null;newBytes=null;status.textContent='新しい元図PDFを選択してください。';updateLabels()}}};
 moveFrom.onchange=async()=>{const next=moveFrom.value;if(maps.some(m=>m.pending||m.confirmed)&&!confirm('移動元を変えると、今回の位置合わせを初期化します。よろしいですか？')){moveFrom.value=maps[0].old;return}moveFrom.value=next;await loadTarget(source.pdfBytes,source.pdfFileName)};

 async function applyUpdate(){if(busy||!newDoc||!ready())return;if(mode.value==='copy'&&!name.value.trim())throw Error('新しい案件名を入力してください');
   if(mode.value==='move'){const m=maps[0];const record=movePageArrows(source,m.old,m.target,oldSizes[m.old],newSizes[m.target],m.transform,m.scaleSymbols);const outside=record.arrows.filter(a=>a.page===m.target&&(a.x<0||a.x>1||a.y<0||a.y>1)).length;if(outside&&!confirm('移動先の用紙外に'+outside+'件の矢視があります。確定しますか？'))return;busy=true;updateLabels();cancel.disabled=true;try{await commit(record,'move');busy=false;finish(true)}catch(e){status.textContent='移動できませんでした：'+e.message}finally{busy=false;cancel.disabled=false;updateLabels()}return}
   let nextPage=newDoc.numPages;const complete=maps.map(m=>m.target==='keep'?{...m,target:++nextPage,transform:identity(),scaleSymbols:false}:{...m});
   const dimensions={...newSizes};for(const m of complete)if(m.target>newDoc.numPages)dimensions[m.target]=oldSizes[m.old];
   const result=buildPlacement(source,complete,dimensions,oldSizes);if(result.outside&&!confirm('用紙外に'+result.outside+'件の矢視があります。位置合わせを確定しますか？'))return;
   busy=true;updateLabels();cancel.disabled=true;file.disabled=true;status.textContent='PDFと矢視を保存しています…';
   try{let bytes=newBytes;if(nextPage>newDoc.numPages){const target=await PDFDocument.load(newBytes),original=await PDFDocument.load(source.pdfBytes);const kept=complete.filter(m=>m.target>newDoc.numPages);const copied=await target.copyPages(original,kept.map(m=>m.old-1));for(const p of copied)target.addPage(p);bytes=await target.save()}
     const pageIds=await mapPageIdentity(source,oldDoc.numPages,complete,nextPage);
     const record={...source,pageEdits:transferPageEdits(source,complete,pageIds,newDoc.numPages),pageIds,pdfBytes:bytes,pdfFileName:newName,arrows:result.arrows,pageStyles:result.pageStyles,currentPage:complete.find(m=>m.old===(source.currentPage||1))?.target||1,name:mode.value==='copy'?name.value.trim():source.name};
     await commit(record,mode.value);busy=false;finish(true);
   }catch(e){status.textContent='確定できませんでした。元の案件は保持しています：'+e.message}finally{busy=false;cancel.disabled=false;file.disabled=false;updateLabels()}
 }
 try{oldDoc=await doc(source.pdfBytes);oldSizes=await sizes(oldDoc);for(let n=1;n<=oldDoc.numPages;n++){const o=element('option',n+'ページ（矢視 '+source.arrows.filter(a=>(a.page||1)===n).length+'個）');o.value=n;moveFrom.append(o)}moveFrom.value=source.currentPage||1;mode.querySelector('option[value=move]').disabled=oldDoc.numPages<2;mode.disabled=false;if(closed){await oldDoc.loadingTask.destroy();return false}file.disabled=false;status.textContent='新しい元図PDFを選択してください。'}catch(e){status.textContent='元図を開けません：'+e.message}
 return completed;
}
function drawArrow(c,p,angle,s,n,fontData,userUnit){drawArrowSymbol(c,p,angle,s,n,fontData,userUnit)}
