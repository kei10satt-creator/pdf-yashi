// Prefer wheel tick evidence to pixel magnitude (which varies with DPI/scroll settings).
export function wheelIntent(e){
 if(e.ctrlKey)return 'pinch';
 if(e.deltaMode!==0)return 'zoom';
 if(e.deltaX||e.shiftKey)return 'pan';
 const tick=Number(e.wheelDeltaY||e.wheelDelta||0);
 if(tick&&Math.abs(tick/120-Math.round(tick/120))<1e-6)return 'zoom';
 if(tick&&Math.abs(tick+e.deltaY*3)<.05)return 'pan';
 return 'zoom';
}
