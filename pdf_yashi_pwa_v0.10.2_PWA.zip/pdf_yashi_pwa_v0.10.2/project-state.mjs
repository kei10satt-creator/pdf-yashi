function canonical(v){if(typeof v==='number')return Number.isFinite(v)?Math.round(v*1e12)/1e12:v;if(Array.isArray(v))return v.map(canonical);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().filter(k=>v[k]!==undefined).map(k=>[k,canonical(v[k])]));return v}
export async function fingerprint(d){
 const bytes=d.pdfBytes instanceof Uint8Array?d.pdfBytes:new Uint8Array(d.pdfBytes||[]);
 const pdf=hex(await crypto.subtle.digest('SHA-256',bytes));
 const styles={};for(const [n,s] of Object.entries(d.pageStyles||{})){const merged={...d.style,...s};if(JSON.stringify(canonical(merged))!==JSON.stringify(canonical(d.style)))styles[n]=merged}
 const arrows=(d.arrows||[]).map(a=>({...a,page:a.page||1,photoId:a.photoId||null})).sort((a,b)=>String(a.id).localeCompare(String(b.id)));
 const content={pdf,...(d.pageEdits&&Object.keys(d.pageEdits.pages||{}).length?{pageEdits:d.pageEdits}:{}),...(d.pageIds?{pageIds:d.pageIds}:{}),name:d.name,pdfFileName:d.pdfFileName,style:d.style,pageStyles:styles,arrows,photoLedgerCache:d.photoLedgerCache||null};
 return hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(canonical(content)))));
}
function hex(buffer){return Array.from(new Uint8Array(buffer),b=>b.toString(16).padStart(2,'0')).join('')}
export function mergeSaved(old,d,hash){const result={...old,...d,saveTarget:'app',fileHandle:null,contentFingerprint:hash};delete result.sync;delete result.localRev;if(old?.contentFingerprint===hash)result.updatedAt=old.updatedAt;return result}
export function isUnexported(d){return !d.exportedFingerprint||d.contentFingerprint!==d.exportedFingerprint}
export function markExported(d,hash,at){return {...d,exportedFingerprint:hash,exportedAt:at}}
export function recentGroups(rows,lastClosedId){const sorted=[...rows].sort((a,b)=>String(b.lastUsedAt||b.updatedAt||'').localeCompare(String(a.lastUsedAt||a.updatedAt||''))||(a.projectId===lastClosedId?-1:b.projectId===lastClosedId?1:0));const recent=sorted.slice(0,5),ids=new Set(recent.map(d=>d.projectId));return{recent,older:sorted.filter(d=>!ids.has(d.projectId)&&isUnexported(d)&&!d.hideUnexportedWarning),all:sorted}}
