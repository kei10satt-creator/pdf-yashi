// Session-only history. PDF buffers and ledger objects are immutable shared
// assets; editing metadata is cloned. No history enters .yashi or IndexedDB.
const ledgerKeys=new WeakMap();
export function cloneEditData(value){return typeof structuredClone==='function'?structuredClone(value):JSON.parse(JSON.stringify(value))}
function canonical(v){if(typeof v==='number')return Number.isFinite(v)?Math.round(v*1e12)/1e12:v;if(Array.isArray(v))return v.map(canonical);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().filter(k=>v[k]!==undefined).map(k=>[k,canonical(v[k])]));return v}
function ledgerKey(v){if(!v)return '';if(!ledgerKeys.has(v))ledgerKeys.set(v,JSON.stringify(v));return ledgerKeys.get(v)}
function take(d){const state={pageEdits:cloneEditData(d.pageEdits||{schemaVersion:1,unit:"mm-paper",coordinates:"displayed page top-left; +X right; +Y down; after PDF rotation; before pdfTransform",pages:{}}),projectId:d.projectId,cadProjectId:d.cadProjectId,name:d.name,pdfFileName:d.pdfFileName,pageIds:[...d.pageIds],currentPage:d.currentPage,applyStyleAll:d.applyStyleAll,style:cloneEditData(d.style),pageStyles:cloneEditData(d.pageStyles||{}),arrows:cloneEditData(d.arrows||[]),pdfBytes:d.pdfBytes,photoLedgerCache:d.photoLedgerCache};
 const styles={};for(const [n,s] of Object.entries(state.pageStyles))if(JSON.stringify(canonical({...state.style,...s}))!==JSON.stringify(canonical(state.style)))styles[n]=s;
 const key=JSON.stringify(canonical({pageEdits:state.pageEdits,name:state.name,pdfFileName:state.pdfFileName,pageIds:state.pageIds,style:state.style,pageStyles:styles,applyStyleAll:state.applyStyleAll,arrows:[...state.arrows].sort((a,b)=>String(a.id).localeCompare(String(b.id)))}));
 return {state,key};
}
function same(a,b){return a.key===b.key&&a.state.pdfBytes===b.state.pdfBytes&&ledgerKey(a.state.photoLedgerCache)===ledgerKey(b.state.photoLedgerCache)}
export function displaySafe(a,b){return a.pdfBytes===b.pdfBytes&&JSON.stringify(a.pageIds)===JSON.stringify(b.pageIds)&&ledgerKey(a.photoLedgerCache)===ledgerKey(b.photoLedgerCache)&&JSON.stringify(a.arrows.map(x=>[x.id,x.page,x.photoId||null]).sort())===JSON.stringify(b.arrows.map(x=>[x.id,x.page,x.photoId||null]).sort())}
export class EditHistory{
 constructor({limit=100,assetLimit=256*1024*1024}={}){this.limit=limit;this.assetLimit=assetLimit;this.clear()}
 clear(){this.entries=[];this.index=-1}
 reset(d){this.entries=[take(d)];this.index=0}
 capture(d){const next=take(d);if(this.index<0){this.reset(d);return false}if(same(this.entries[this.index],next)){this.entries[this.index].state.currentPage=d.currentPage;return false}this.entries.splice(this.index+1);this.entries.push(next);this.index++;this.trim();return true}
 trim(){const size=()=>{const assets=new Set();let n=0;for(const e of this.entries){n+=e.key.length*2;for(const [a,bytes] of [[e.state.pdfBytes,e.state.pdfBytes?.byteLength||0],[e.state.photoLedgerCache,ledgerKey(e.state.photoLedgerCache).length*2]])if(a&&!assets.has(a)){assets.add(a);n+=bytes}}return n};while(this.entries.length>2&&(this.entries.length>this.limit+1||size()>this.assetLimit)){this.entries.shift();this.index--}}
 target(direction){return this.entries[this.index+direction]?.state||null}
 accept(direction){if(this.target(direction))this.index+=direction}
 get current(){return this.entries[this.index]?.state||null}
}
