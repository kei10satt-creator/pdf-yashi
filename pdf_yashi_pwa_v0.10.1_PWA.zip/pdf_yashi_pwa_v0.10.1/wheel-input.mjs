// Browser WheelEvent has no physical device identity. Fixed event routing only.
export function wheelIntent(e){if(e.ctrlKey)return 'pinch';if(e.deltaMode!==0)return 'zoom';if(e.deltaX||e.shiftKey)return 'pan';const n=Math.abs(e.deltaY);return n>=80&&(n%100===0||n%120===0)?'zoom':'pan'}
