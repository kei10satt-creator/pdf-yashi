import {PDFOperator,rgb,pushGraphicsState,popGraphicsState,moveTo,lineTo,closePath,clip,endPath,setFillingRgbColor} from './lib/pdf-lib.mjs';
import {outputFrame,frameCorners} from './output-frame.mjs';
import {paperCoordinates} from './cad-symbol.mjs';
import {multiply,inverse,apply,rectPoints} from './drawing-model.mjs';
// CAD uses bottom-left paper coordinates; drawing tools use top-left paper coordinates.
export function pdfToDrawing(info){const p=paperCoordinates(info);return multiply([1,0,0,-1,0,p.height],p.pdfToPaper)}
export async function composeDrawing(doc,info,edits){
 if(!edits)return;const page=doc.getPage(info.page-1),toPaper=pdfToDrawing(info),toPdf=inverse(toPaper),k=72/25.4/(info.userUnit||1),m=multiply(toPdf,multiply(edits.pdfTransform,toPaper));
 // Wrap only original content: masks/drawing and arrows must not follow the source transform.
 if(edits.outputFrame||m.some((v,i)=>Math.abs(v-[1,0,0,1,0,0][i])>1e-10)){
  const [x,y,X,Y]=info.pdfBox;page.node.normalize();const start=doc.context.register(doc.context.flateStream(`q\n${m.join(' ')} cm\n${x} ${y} ${X-x} ${Y-y} re W n\n`)),end=doc.context.register(doc.context.flateStream('\nQ\n'));page.node.wrapContentStreams(start,end);
 }
 const path=(points,fill,lineWidth)=>{const ps=points.map(p=>apply(toPdf,p)),[x,y]=ps[0];page.drawSvgPath('M 0 0 '+ps.slice(1).map(p=>`L ${p[0]-x} ${y-p[1]}`).join(' ')+' Z',{x,y,...(fill?{color:rgb(1,1,1)}:{borderColor:rgb(.067,.067,.067),borderWidth:lineWidth*k})})};
 const frame=outputFrame(edits,paperCoordinates(info)),polygon=points=>{const ps=points.map(p=>apply(toPdf,p));return[moveTo(...ps[0]),...ps.slice(1).map(p=>lineTo(...p)),closePath()]};
 for(const o of edits.objects.filter(o=>o.type==='maskGroup')){page.pushOperators(pushGraphicsState(),...polygon(frameCorners(frame)),clip(),endPath(),setFillingRgbColor(1,1,1));for(const p of o.geometry.polygons){const ops=o.geometry.keep==='inside'?[...polygon(frameCorners(frame)),...polygon(p.points),PDFOperator.of('f*')]:[...polygon(p.points),PDFOperator.of('f')];page.pushOperators(...ops)}page.pushOperators(popGraphicsState())}
 for(const o of edits.objects.filter(o=>o.type!=='maskGroup')){const g=o.geometry,w=o.style.lineWidth*k,color=rgb(.067,.067,.067);
  if(o.type==='line'){const a=apply(toPdf,g.start),b=apply(toPdf,g.end);page.drawLine({start:{x:a[0],y:a[1]},end:{x:b[0],y:b[1]},thickness:w,color,lineCap:0})}
  else if(o.type==='rectangle'||o.type==='polygon')path(g.points||rectPoints(g.start,g.end),false,o.style.lineWidth);
  else if(o.type==='circle'){const p=apply(toPdf,g.center);page.drawCircle({x:p[0],y:p[1],size:g.radius*k,borderColor:color,borderWidth:w})}
  else if(o.type==='text'){
   // Rasterize text alone at 600 dpi: CJK glyphs remain identical to the current device's canvas.
   // PDF geometry stays vector; editable text remains in .yashi and CAD JSON.
   if(typeof document==='undefined')throw Error('文字入りPDFはアプリ画面から書き出してください');
   const dpi=600,ratio=dpi/25.4,size=o.style.fontSize,measure=document.createElement('canvas').getContext('2d');measure.font=`${size*ratio}px sans-serif`;const metric=measure.measureText(g.text),left=Math.max(0,metric.actualBoundingBoxLeft),right=Math.max(metric.width,metric.actualBoundingBoxRight),ascent=Math.max(size*ratio,metric.actualBoundingBoxAscent),descent=Math.max(size*.3*ratio,metric.actualBoundingBoxDescent),pad=2;
   const canvas=document.createElement('canvas');canvas.width=Math.ceil(left+right+pad*2);canvas.height=Math.ceil(ascent+descent+pad*2);if(canvas.width>32760||canvas.height>32760||canvas.width*canvas.height>64000000)throw Error('文字が大きすぎます。文字数・サイズを分けてください');const c=canvas.getContext('2d');c.font=measure.font;c.fillStyle='#111';c.fillText(g.text,left+pad,ascent+pad);const image=await doc.embedPng(canvas.toDataURL('image/png'));
   const top=[g.position[0]-(left+pad)/ratio,g.position[1]-(ascent+pad)/ratio],width=canvas.width/ratio,height=canvas.height/ratio,origin=apply(toPdf,[top[0],top[1]+height]);page.drawImage(image,{x:origin[0],y:origin[1],width:width*k,height:height*k,rotate:{type:'degrees',angle:info.rotation}});
  }
 }
}
export function applyOutputFrame(doc,info,edits){if(!edits?.outputFrame)return;const inv=inverse(pdfToDrawing(info)),ps=frameCorners(edits.outputFrame).map(p=>apply(inv,p)),x=Math.min(...ps.map(p=>p[0])),y=Math.min(...ps.map(p=>p[1])),w=Math.max(...ps.map(p=>p[0]))-x,h=Math.max(...ps.map(p=>p[1]))-y,p=doc.getPage(info.page-1);p.setMediaBox(x,y,w,h);p.setCropBox(x,y,w,h);p.setTrimBox(x,y,w,h);p.setBleedBox(x,y,w,h);p.setArtBox(x,y,w,h)}
