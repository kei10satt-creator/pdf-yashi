# PDF矢視 v0.10.0 — CAD交換JSON pageEdits追加仕様

既存の「Vectorworks_CAD交換JSON仕様.md」と併用してください。
YASHI_CAD_EXCHANGEのversionは2、vectorworksSymbol.schemaVersionは1を維持します。
既存のprojectId、pages、pageId、arrows、arrowId、photoId、vectorworksSymbol、sourcePdfの構造・座標は変更しません。

## 追加フィールド

トップレベルに次の構造を追加します。.yashiの編集データも同じ構造です。

```json
{
  "pageEdits": {
    "schemaVersion": 1,
    "unit": "mm-paper",
    "coordinates": "displayed page top-left; +X right; +Y down; after PDF rotation; before pdfTransform",
    "pages": {
      "対象ページのpageId": {
        "pdfTransform": [1, 0, 0, 1, 0, 0],
        "objects": []
      }
    }
  }
}
```

pagesのキーは既存pages[].pageIdと照合します。恒久IDでありページ番号ではありません。
pageEditsまたは対象ページのエントリーがない場合は、PDF変換なし・作図なしです。
対応しないschemaVersionは黙って描画せず、非対応を表示してください。
新しいPDF編集を再現する必要があるデータでは、この拡張を無視すると元図の位置・マスク・追記が異なります。

## 座標と変換

ページのCropBox／Rotate／UserUnitを反映した「画面で見える用紙」の左上を(0,0)、右を+X、下を+Yとします。
長さは印刷紙面mmです。既存arrowsのPDF user-spaceやvectorworks.positionの左下基準とは異なります。
既存pages[].paperCoordinatesのwidth、heightを使用できます。

pdfTransformは [a,b,c,d,e,f] です。

```
x' = a*x + c*y + e
y' = b*x + d*y + f
```

a,b,c,dは無次元、e,fは紙面mm。元PDFだけへ適用する相似変換です。
作図オブジェクトと矢視には、この変換を重ねて適用しないでください。
用紙サイズ自体は変更しません。結果は用紙の範囲でクリップします。

既存pdfToPaperをB、用紙高さをH、上下反転行列F=[1,0,0,-1,0,H]とすると、PDF user-spaceから本拡張の座標への変換はD=F×Bです。
PDFの元コンテンツへ適用する変換は Dの逆行列 × pdfTransform × D です。
Vectorworksへ渡す配置点は(x,H-y)で左下基準へ変換できます。図面縮尺は取込側で指定します。

## オブジェクト

全オブジェクトはobjectId（安定したUUID）、type、geometry、style、unit:"mm-paper"を持ちます。
所属ページは外側のpageIdキーから決まります。コピー時だけ新しいobjectIdを発行します。
PDF更新・Undo・保存再読込ではobjectIdを維持します。

| type | geometry | style |
|---|---|---|
| line | start:[x,y], end:[x,y] | lineWidth |
| rectangle | start:[x,y], end:[x,y]（対角2点） | lineWidth |
| polygon | points:[[x,y],…]（末尾と先頭を閉じる） | lineWidth |
| circle | center:[x,y], radius | lineWidth |
| text | position:[x,y], text:"文字列" | fontSize |
| maskGroup | polygons:[{type:"rectangle"または"polygon", points:[[x,y],…]},…] | {} |

rectangleの2点は逆順になることがあります。最小・最大で境界を求めてください。
polygonおよびmaskGroupの各polygonは独立した閉じた輪郭です。複数polygonを1本の輪郭へ連結しないでください。
マスクは白塗り・線なしです。穴のある複合パスへ勝手に変換しないでください。
通常図形は塗りなし・線色#111111・butt線端・miter結合です。
lineWidth、radius、fontSize、各点の値は紙面mmです。
text.positionは左側の文字ベースライン起点です。fontSizeはem高さ、ポイント値=mm×72/25.4です。
テキストは横書き1行・標準sans-serif・通常太さ・#111111。矢視番号用のLiberation Sans Boldとは別です。
書体の解決はアプリ実行端末のフォントに依存します。作図文字用フォントデータはこの拡張に内包しません。
PDF書き出しでは文字部分を600dpiで画像化しますが、本JSONでは編集可能な文字列・位置・サイズを保持します。

図面枠専用typeはありません。挿入時にrectangle、line、textへ展開済みです。
単純コピーの対象はline／rectangle／polygon／circle／textです。矢視・PDF・maskGroupは対象外です。

## 描画順

1. sourcePdfの該当ページへpdfTransformを適用
2. objects内のmaskGroup（配列順）
3. objects内のそれ以外の図形・文字（配列順）
4. 既存のarrows／vectorworksSymbol（従来の用途別番号・表示ルール）

元PDFは従来どおり元のバイト列をBase64で内包します。作図合成済みPDFへの差し替えではありません。
sourcePdfの復元・ページ数・ハッシュ検証の方法は既存仕様のままです。

## PDF更新・ページ管理

新旧ページの対応でpageIdを引き継ぎます。作図の各配置点も位置合わせの相似変換で移します。
円の半径・図形の輪郭は配置変換に追従します。線幅と文字サイズは「記号サイズも変更」を選んだ場合のみ同倍率にします。
テキストは配置位置を変換し、向きは水平を維持します。
四角形を回転した場合はpolygonに変換しますが、objectIdは維持します。
差し替え先のpdfTransformは単位行列に戻します。旧PDFの変形を新PDFへ二重に適用しません。
旧ページを残す場合はpdfTransformも含めてそのまま保持します。
矢視だけのページ間移動では本拡張を変更しません。
削除ページの編集情報は削除し、追加ページは新しいpageIdで編集情報なしになります。

## 互換性

従来の矢視・番号・ID・座標・元PDFフィールドは削除・改名しません。
既存取込側は従来部分を読み取れますが、pageEdits非対応では完成図を再現できません。
Vectorworks側で本拡張を読む処理は今回のアプリ配布物には含みません。
