import {clone,emptyPage,transformObject,paintObject} from './drawing-model.mjs';
const PX_PER_MM=1.7*72/25.4;
// Registration works in displayed viewport pixels. Convert translation to paper mm.
export function transferPageEdits(source,mappings,pageIds,newPageCount){
 if(!source.pageEdits)return undefined;
 const result=clone(source.pageEdits);result.pages={};
 for(const m of mappings){const oldId=source.pageIds[m.old-1],nextId=pageIds[m.target-1],old=source.pageEdits.pages[oldId];if(!old)continue;if(m.target>newPageCount){result.pages[nextId]=clone(old);continue}const t=m.transform,matrix=[t.a,t.b,-t.b,t.a,t.tx/PX_PER_MM,t.ty/PX_PER_MM];result.pages[nextId]={...emptyPage(),objects:old.objects.map(o=>transformObject(o,matrix,m.scaleSymbols))};}
 return result;
}
export function paintEditedPage(canvas,edits,k=PX_PER_MM){if(!edits)return;const copy=document.createElement('canvas');copy.width=canvas.width;copy.height=canvas.height;copy.getContext('2d').drawImage(canvas,0,0);const c=canvas.getContext('2d');c.clearRect(0,0,canvas.width,canvas.height);c.fillStyle='white';c.fillRect(0,0,canvas.width,canvas.height);c.save();const m=edits.pdfTransform;c.setTransform(m[0],m[1],m[2],m[3],m[4]*k,m[5]*k);c.drawImage(copy,0,0);c.restore();c.save();c.scale(k,k);for(const o of [...edits.objects.filter(o=>o.type==='maskGroup'),...edits.objects.filter(o=>o.type!=='maskGroup')])paintObject(c,o);c.restore()}
