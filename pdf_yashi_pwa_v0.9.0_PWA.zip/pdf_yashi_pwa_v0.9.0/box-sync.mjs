// Sync metadata remains local. Every write uses a persisted operation ID and Box ETag.
export function payload(d){
 const bytes=new Uint8Array(d.pdfBytes||[]);let binary='';
 for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
 return {format:'YASHI_PROJECT',version:'0.9.0',projectId:d.projectId,name:d.name,pdfFileName:d.pdfFileName,
 pdfBase64:btoa(binary),photoLedgerCache:d.photoLedgerCache||null,style:d.style,pageStyles:d.pageStyles||{},
 applyStyleAll:!!d.applyStyleAll,arrows:d.arrows||[],currentPage:d.currentPage||1};
}
export function contentKey(d){return JSON.stringify(payload(d))}
export function decode(p){
 if(p?.format!=='YASHI_PROJECT'||typeof p.pdfBase64!=='string'||!Array.isArray(p.arrows)||!p.style)throw Error('矢視案件の形式が不正です');
 const raw=atob(p.pdfBase64);return {...p,pdfBytes:Uint8Array.from(raw,c=>c.charCodeAt(0)),saveTarget:'app',fileHandle:null};
}
export function localChange(old,d,id=()=>crypto.randomUUID()){
 const same=old&&contentKey(old)===contentKey(d);
 return {...d,updatedAt:same?old.updatedAt:d.updatedAt,localRev:same?old.localRev:id(),sync:old?.sync||null};
}
export function pending(d){return !!d.sync&&d.localRev!==d.sync.syncedRev}
export function groupName(d){return d.sync?.fileId?d.sync.folder.path:'端末内のみ（共有先未設定）'}
const safe=s=>String(s||'案件').replace(/[\\/:*?"<>|]/g,'_').slice(0,90);
export class BoxSync {
 constructor({store,api,device='端末',active=()=>null,notify=()=>{}}){Object.assign(this,{store,api,device,active,notify});this.running=null;this.lastError='';this.checkedAt=null}
 run(folders){if(this.running)return this.running;this.running=this.cycle(folders).finally(()=>{this.running=null;this.notify()});this.notify();return this.running}
 async cycle(folders){this.lastError='';this.remoteChanged=false;try{
   // Upload local changes first; a conditional failure produces a separate immutable copy.
   for(const d of await this.store.all())if(pending(d))await this.push(d);
   for(const folder of folders)await this.pullFolder(folder);
   this.checkedAt=new Date().toISOString();
 }catch(e){this.lastError=e.message;throw e}}
 async assign(id,folder){await this.store.update(id,d=>{
   if(d.sync?.folder.id===folder.id)return d;
   if(pending(d))throw Error('先に現在の共有先への未送信データを同期してください');
   return {...d,localRev:d.localRev||crypto.randomUUID(),sync:{folder:{...folder},syncedRev:null}};
 });this.notify()}
 async push(initial){
   const id=initial.projectId;
   // Freeze the payload durably before sending: retries reuse it even if editing continues.
   let d=await this.store.update(id,current=>{
     if(current.sync.operation)return current;
     return {...current,sync:{...current.sync,operation:{id:crypto.randomUUID(),rev:current.localRev,
       body:{...payload(current),updatedAt:current.updatedAt},name:current.sync.fileName||safe(current.name)+'.yashi'}}};
   });
   const op=d.sync.operation;let meta;
   if(d.sync.fileId&&!op.conflict){
     meta=await this.api.meta(d.sync.fileId);
     const remote=await this.api.read(meta);
     if(remote.boxOperationId===op.id)return this.finish(d,meta);
     if(meta.etag===d.sync.etag){
       try {meta=await this.api.upload(d.sync.folder.id,d.sync.fileId,meta.etag,op.name,{...op.body,boxOperationId:op.id});return this.finish(d,meta)}
       catch(e){if(e.status!==412)throw e}
     }
     d=await this.store.update(id,c=>({...c,sync:{...c.sync,operation:{...c.sync.operation,conflict:true,
       name:safe(op.body.name)+'（競合・'+safe(this.device)+'・'+op.id.slice(0,8)+'）.yashi'}}}));
   }
   const frozen=d.sync.operation;
   // Deterministic unique name + operation ID resolves lost-response retries without extra copies.
   const name=frozen.name;
   let existing=(await this.api.list(d.sync.folder.id)).find(x=>x.type==='file'&&x.name===name);
   if(existing){meta=await this.api.meta(existing.id);const p=await this.api.read(meta);if(p.boxOperationId!==frozen.id){
     if(frozen.conflict)throw Error('同名の別データがあります。自動上書きは行いません');
     await this.store.update(id,c=>({...c,sync:{...c.sync,operation:{...c.sync.operation,conflict:true,name:safe(frozen.body.name)+'（競合・'+safe(this.device)+'・'+frozen.id.slice(0,8)+'）.yashi'}}}));
     return this.push(await this.store.update(id,c=>c));
   }}
   else {try{meta=await this.api.upload(d.sync.folder.id,null,null,name,{...frozen.body,boxOperationId:frozen.id,boxConflict:!!frozen.conflict})}
     catch(e){if(e.status!==409)throw e;existing=(await this.api.list(d.sync.folder.id)).find(x=>x.name===name);if(!existing)throw e;return this.push(await this.store.update(id,c=>c))}}
   return this.finish(d,meta);
 }
 async finish(d,meta){if(!meta?.id||typeof meta.etag!=='string'||!meta.modified_at)throw Error('Boxの保存結果を確認できません。再同期してください');await this.store.update(d.projectId,c=>{
   if(c.sync?.operation?.id!==d.sync.operation.id)return c;
   return {...c,sync:{...c.sync,fileId:meta.id,fileName:meta.name,etag:meta.etag,boxModifiedAt:meta.modified_at,
     syncedRev:d.sync.operation.rev,operation:null,conflict:!!d.sync.operation.conflict||!!c.sync.conflict}};
 });this.notify()}
 async pullFolder(folder,seen=new Set()){
   if(seen.has(folder.id))return;seen.add(folder.id);
   for(const entry of await this.api.list(folder.id)){
     if(entry.type==='folder'){await this.pullFolder({id:entry.id,path:folder.path+' → '+entry.name},seen);continue}
     if(entry.type!=='file'||!entry.name.toLowerCase().endsWith('.yashi'))continue;
     const rows=await this.store.all(),old=rows.find(d=>d.sync?.fileId===entry.id);
     const meta=await this.api.meta(entry.id);
     if(old&&this.active()===old.projectId&&old.sync.etag!==meta.etag)this.remoteChanged=true;
     if(old&&(pending(old)||this.active()===old.projectId||old.sync.etag===meta.etag))continue;
     const p=await this.api.read(meta),decoded=decode(p),rev=crypto.randomUUID();
     const id=old?.projectId||'box:'+entry.id;
     await this.store.update(id,current=>{
       if(current&&(pending(current)||this.active()===id))return current;
       return {...decoded,projectId:id,localRev:rev,sync:{folder,fileId:meta.id,fileName:meta.name,etag:meta.etag,boxModifiedAt:meta.modified_at,syncedRev:rev,conflict:!!p.boxConflict}};
     });
   }
 }
}
