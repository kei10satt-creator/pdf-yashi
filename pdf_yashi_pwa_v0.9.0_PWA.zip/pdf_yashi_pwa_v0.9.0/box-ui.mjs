import {BoxSync,localChange,pending,groupName} from './box-sync.mjs';
import {BoxAPI} from './box-api.mjs';
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text)n.textContent=text;if(cls)n.className=cls;return n};
const button=(text,fn)=>{const b=el('button',text);b.onclick=()=>Promise.resolve().then(fn).catch(e=>alert(e.message));return b};
const date=s=>s?new Date(s).toLocaleString():'—';
async function configDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open('pdf-yashi-box',1);r.onupgradeneeded=()=>r.result.createObjectStore('settings');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function settings(value){const db=await configDB();return new Promise((resolve,reject)=>{const t=db.transaction('settings',value?'readwrite':'readonly'),s=t.objectStore('settings'),r=value?s.put(value,'config'):s.get('config');t.oncomplete=()=>{db.close();resolve(value||r.result)};t.onerror=()=>{db.close();reject(t.error)}})}
export async function mountBox(hooks){
 let config=await settings()||{url:'',key:'',device:/iPad|iPhone/.test(navigator.userAgent)?'iPad':'Windows',folders:[]};
 config.folders||=[];
 const api=new BoxAPI(()=>config),store={all:hooks.all,update:hooks.update};
 const engine=new BoxSync({store,api,device:config.device,active:hooks.active,notify:()=>refresh().catch(console.warn)});
 let timer,listMode=null,listEpoch=0,inFlight=null;
 const saveConfig=async()=>settings(config);
 async function refresh(){const rows=await store.all(),waiting=rows.filter(pending).length,conflicts=rows.filter(d=>d.sync?.conflict).length,localOnly=rows.filter(d=>!d.sync).length;
   const text=inFlight||engine.running?'Box同期中…':engine.lastError?'Box同期未完了：'+engine.lastError:!config.url?'端末内保存・Box未設定':!navigator.onLine?'オフライン・Boxは前回確認時の情報':engine.remoteChanged?'Boxに更新あり・案件を開き直してください':waiting?'未送信 '+waiting+'件':!engine.checkedAt?'Box未確認':conflicts?'競合あり・両方保存済み':'Box同期済み・作業できます';
   for(const n of document.querySelectorAll('.boxStatus')){n.textContent=text+(localOnly?' ／端末内のみ '+localOnly+'件':'');n.dataset.state=waiting||engine.lastError||engine.remoteChanged?'waiting':engine.running?'busy':'ready'}
   if(listMode&&!document.getElementById('fileListModal').classList.contains('hidden'))await renderList(listMode);
 }
 function run(){if(inFlight)return inFlight;inFlight=syncRun().finally(()=>{inFlight=null;refresh().catch(console.warn)});refresh().catch(console.warn);return inFlight}
 async function syncRun(){if(!config.url||!navigator.onLine){return false}try{const status=await api.status();
   if(config.account&&config.account!==status.user.id)throw Error('Boxアカウントが以前と異なります。元のアカウントで接続してください');
   config.account=status.user.id;await saveConfig();await engine.run(config.folders);return !engine.remoteChanged&&!(await store.all()).some(pending);
 }catch(e){engine.lastError=e.message;await refresh();return false}}
 function schedule(){clearTimeout(timer);timer=setTimeout(run,3000)}
 function dialog(title){const cover=el('div',null,'boxModal'),panel=el('section',null,'boxPanel'),head=el('div',null,'boxHead');head.append(el('h3',title),button('閉じる',()=>cover.remove()));panel.append(head);cover.append(panel);document.body.append(cover);return {cover,panel}}
 async function folderPicker(onChoose){const {cover,panel}=dialog('Boxの共有先フォルダを選択');const tree=el('div');panel.append(tree);
   if(!navigator.onLine){tree.append(el('p','オフライン：以前設定した共有先から選べます。送信は再接続後に行います。'));for(const f of config.folders)tree.append(button(f.path,async()=>{await onChoose(f);cover.remove()}));if(!config.folders.length)tree.append(el('p','記録済みの共有先がありません。オンラインで設定してください。'));return}
   async function show(folder,parents=[]){tree.replaceChildren(el('p',folder.path));if(parents.length)tree.append(button('一つ上へ',()=>show(parents.at(-1),parents.slice(0,-1))));
     tree.append(button('このフォルダを共有先にする',async()=>{await onChoose(folder);cover.remove()}));
     const children=(await api.list(folder.id)).filter(x=>x.type==='folder');
     for(const c of children)tree.append(button('📁 '+c.name,()=>show({id:c.id,path:folder.path+' → '+c.name},[...parents,folder])));
     if(!children.length)tree.append(el('p','下位フォルダはありません'));
   }
   panel.prepend(button('Boxのルートから選ぶ',()=>show({id:'0',path:'Box'})));
   try{await show(config.defaultFolder||{id:'0',path:'Box'})}catch(e){tree.textContent=e.message}
 }
 async function register(folder){if(!config.folders.some(f=>f.id===folder.id))config.folders.push(folder);config.defaultFolder=folder;await saveConfig()}
 async function openSettings(){const {panel}=dialog('Box共有設定');
   panel.append(el('p','この端末の保存場所：矢視アプリ専用領域。Boxの秘密情報はここには入力しません。'));
   const fields={};for(const [k,label,type] of [['url','接続サーバーURL','url'],['key','接続キー','password'],['device','この端末の名前','text']]){const l=el('label',label),input=el('input');input.type=type;input.value=config[k]||'';input.autocomplete='off';l.append(input);panel.append(l);fields[k]=input}
   const note=el('p');panel.append(note);
   async function commit(){if(inFlight)throw Error('同期の完了後に設定を変更してください');const url=fields.url.value.trim();if(url){const u=new URL(url);if(u.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(u.hostname))throw Error('HTTPSの接続先を指定してください');if(u.pathname!=='/'||u.search||u.hash||u.username||u.password)throw Error('URLは https://接続サーバー名 の形式で指定してください')}
     if(config.url&&url!==config.url&&(await store.all()).some(d=>d.sync))throw Error('共有中の案件があるため接続サーバーの変更はできません。共有フォルダは下のボタンで変更できます');
     config={...config,url,key:fields.key.value.trim(),device:fields.device.value.trim()||'端末'};engine.device=config.device;await saveConfig();await refresh()}
   panel.append(button('設定を保存',async()=>{await commit();note.textContent='設定を保存しました'}));
   panel.append(button('Boxへログイン',async()=>{await commit();const result=await api.login();const a=el('a','Boxログイン画面を開く');a.href=result.url;a.target='_blank';a.rel='noopener noreferrer';note.replaceChildren(a)}));
   panel.append(button('接続確認',async()=>{await commit();note.textContent=await run()?'Box接続・同期完了':engine.lastError||'同期状態を確認してください'}));
   panel.append(el('p','新しく選ぶ共有先：'+(config.defaultFolder?.path||'未設定')));
   panel.append(button('共有フォルダを選択・変更',()=>folderPicker(async f=>{await register(f);note.textContent='共有先：'+f.path+'（既存案件の共有先は変更しません）';await run()})));
   panel.append(el('p','案件ごとの共有先は「保存ファイルを開く」で指定できます。設定したフォルダ以下を同期します。'));
 }
 async function renderList(mode){listMode=mode;const epoch=++listEpoch,list=document.getElementById('fileList');const rows=(await store.all()).sort((a,b)=>String(b.updatedAt).localeCompare(String(a.updatedAt))),groups=new Map();if(epoch!==listEpoch)return;list.replaceChildren();
   for(const d of rows){const name=groupName(d);if(!groups.has(name))groups.set(name,[]);groups.get(name).push(d)}
   if(!rows.length)list.append(el('p','保存済み案件はありません。Box共有設定からフォルダを指定すると受信できます。'));
   for(const [path,records] of groups){const section=el('details',null,'boxFolder');section.open=true;section.append(el('summary',path));
     for(const d of records){const row=el('div',null,'boxFile'),info=el('div');info.append(el('strong',d.sync?.fileName||d.name));
       const state=!d.sync?'共有先未設定':!d.sync.fileId?'初回同期待ち':pending(d)?'共有済み・未送信の編集あり':d.sync.conflict?'競合コピー・Box保存済み':'共有済み';
       info.append(el('div',state,'boxSmall'),el('div','この端末にある版のBox最終更新：'+date(d.sync?.boxModifiedAt),'boxSmall'),el('div','端末の最終編集：'+date(d.updatedAt),'boxSmall'));
       if(d.sync)info.append(el('div','共有先：'+d.sync.folder.path,'boxSmall'));
       row.append(info,button(mode==='open'?'開く':'書き出す',async()=>{if(mode==='open'){document.getElementById('fileListModal').classList.add('hidden');await hooks.open(d.projectId)}else await hooks.export(d)}));
       row.append(button(d.sync?'共有先を変更':'共有先を選択',()=>folderPicker(async f=>{await engine.assign(d.projectId,f);await register(f);await run();await renderList(mode)})));section.append(row);
     }list.append(section);
   }
 }
 const home=el('div',null,'boxHome'),status=el('div',null,'boxStatus');status.setAttribute('role','status');home.append(status,button('Box共有設定',openSettings),button('今すぐ同期',run),button('同期を確認して作業終了',async()=>{await hooks.flush();if(await run())alert('この端末のBox同期が完了しました。アプリを閉じられます。');else alert('同期未完了です。端末内のデータは保持しています。表示を確認してください。')}));document.getElementById('card').append(home);
 const top=el('button','Box未確認','boxStatus');top.onclick=async()=>{await hooks.flush();await run()};top.title='クリックでBoxと同期';document.getElementById('projectStatus').prepend(top);
 window.addEventListener('online',run);document.addEventListener('visibilitychange',()=>{if(!document.hidden)run();else hooks.flush().then(run).catch(console.warn)});
 setInterval(()=>{if(!document.hidden)run()},60000);
 await refresh();schedule();
 return {save:localChange,schedule,run,renderList,refresh,settings:openSettings};
}
