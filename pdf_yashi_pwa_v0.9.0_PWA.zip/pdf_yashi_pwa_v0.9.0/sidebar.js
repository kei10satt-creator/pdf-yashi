(() => {
  const panel = document.getElementById('photoPanel');
  const grip = document.getElementById('photoResize');
  const key = 'pdf-yashi-photo-sidebar-width';
  let preferred = 360;
  try { const saved = Number(localStorage.getItem(key)); if (saved >= 174) preferred = saved; } catch {}
  function apply(width) {
    const pages = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--pages-width')) || 164;
    const max = Math.max(174, Math.min(900, innerWidth - pages - 180));
    const value = Math.round(Math.max(174, Math.min(max, width)));
    document.documentElement.style.setProperty('--photos-width', value + 'px');
    grip.setAttribute('aria-valuenow', value);
    grip.setAttribute('aria-valuemin', 174);
    grip.setAttribute('aria-valuemax', max);
    return value;
  }
  function save() { try { localStorage.setItem(key, String(preferred)); } catch {} }
  let drag = null;
  grip.addEventListener('pointerdown', e => {
    if (e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    drag = {id:e.pointerId,x:e.clientX,width:panel.getBoundingClientRect().width};
    grip.setPointerCapture(e.pointerId);
  });
  grip.addEventListener('pointermove', e => {
    if (!drag || drag.id !== e.pointerId) return;
    preferred = apply(drag.width + drag.x - e.clientX);
  });
  function end(e) { if (!drag || drag.id !== e.pointerId) return; drag=null; save(); }
  grip.addEventListener('pointerup', end);
  grip.addEventListener('pointercancel', end);
  grip.addEventListener('lostpointercapture', end);
  grip.addEventListener('keydown', e => {
    if (!['ArrowLeft','ArrowRight','Home','End'].includes(e.key)) return;
    e.preventDefault(); e.stopPropagation();
    preferred=apply(e.key==='Home'?174:e.key==='End'?900:panel.getBoundingClientRect().width+(e.key==='ArrowLeft'?30:-30)); save();
  });
  window.addEventListener('resize', () => apply(preferred));
  apply(preferred);
})();
