export class BoxAPI {
 constructor(config){this.config=config}
 async request(path,body){const c=this.config();if(!c.url||!c.key)throw Error('Box接続を設定してください');
   const url=new URL(c.url);if(url.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(url.hostname))throw Error('接続先にはHTTPSが必要です');
   const r=await fetch(url.origin+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+c.key,...(body?{'Content-Type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,cache:'no-store',signal:AbortSignal.timeout(120000)});
   const data=await r.json();if(!r.ok){const e=Error(data.error||'Box接続エラー');e.status=r.status;throw e}return data;
 }
 status(){return this.request('/status')}
 login(){return this.request('/login',{})}
 list(id){return this.request('/list?id='+encodeURIComponent(id))}
 meta(id){return this.request('/meta?id='+encodeURIComponent(id))}
 read(meta){return this.request('/read?id='+encodeURIComponent(meta.id)+'&etag='+encodeURIComponent(meta.etag))}
 upload(folder,id,etag,name,payload){return this.request('/upload',{folder,id,etag,name,payload})}
}
