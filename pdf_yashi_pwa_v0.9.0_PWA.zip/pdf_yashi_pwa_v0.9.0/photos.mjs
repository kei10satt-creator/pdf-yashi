export const modes = ['all', 'inspection12', 'report', 'survey'];
export function parseLedger(data) {
  if (!data || !Array.isArray(data.photos)) throw new Error('photos 配列がある写真台帳JSONを選択してください。');
  const ids = new Set();
  const photos = data.photos.map((p, i) => {
    if (!p || typeof p.photoId !== 'string' || !p.photoId.trim()) throw new Error(`${i+1}枚目のphotoIdがありません。`);
    if (ids.has(p.photoId)) throw new Error(`photoIdが重複しています：${p.photoId}`);
    ids.add(p.photoId);
    if (!p.numbering || typeof p.numbering !== 'object') throw new Error(`${p.photoId} のnumberingがありません。`);
    const numbering = {};
    for (const mode of modes) {
      const n = p.numbering[mode];
      if (n != null && (!Number.isSafeInteger(n) || n < 1)) throw new Error(`${p.photoId} の ${mode} 番号が不正です。`);
      numbering[mode] = n ?? null;
    }
    return {photoId:p.photoId, description:typeof p.description === 'string' ? p.description : '', numbering,
      thumbnail:typeof p.thumbnail === 'string' && /^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i.test(p.thumbnail) ? p.thumbnail : null};
  });
  return {version:data.version ?? 1, photos};
}
export function photoNumber(photo, mode) { return photo?.numbering?.[mode] ?? null; }
export function visibleArrow(arrow, index, mode, linking, loaded) {
  if (!loaded || linking) return true;
  return photoNumber(index.get(arrow.photoId), mode) !== null;
}
export function orderedPhotos(photos, arrows, mode, linking) {
  const linked = new Set(arrows.map(a=>a.photoId).filter(Boolean));
  return photos.filter(p=>linking || photoNumber(p, mode)!==null).slice().sort((a,b)=>
    (linking ? Number(linked.has(b.photoId))-Number(linked.has(a.photoId)) : 0) ||
    (photoNumber(a,mode) ?? Infinity)-(photoNumber(b,mode) ?? Infinity) || a.photoId.localeCompare(b.photoId));
}
export function nextUnlinked(photos, arrows, currentId) {
  const ordered = orderedPhotos(photos, [], 'all', true), linked = new Set(arrows.map(a=>a.photoId));
  const start = ordered.findIndex(p=>p.photoId===currentId);
  for(let step=1;step<=ordered.length;step++) {
    const p=ordered[(start+step)%ordered.length];
    if(!linked.has(p.photoId)) return p.photoId;
  }
  return null;
}
export function arrowRecord(a, width=1, height=1) {
  return {id:a.id, page:Number.isSafeInteger(a.page)&&a.page>0?a.page:1, x:a.x/width, y:a.y/height, angle:a.angle, photoId:a.photoId || null};
}
