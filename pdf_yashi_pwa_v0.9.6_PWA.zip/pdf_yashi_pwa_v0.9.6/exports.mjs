import {validatePageIds} from './page-identity.mjs';
import {embedNumberFont,numberLayout} from "./number-font.mjs";
import {addSymbolSpecification} from "./cad-symbol.mjs";
import {symbolStyle,arrowStyle} from './registration.mjs';
import {PDFDocument, StandardFonts, rgb} from './lib/pdf-lib.mjs';
import {photoNumber} from './photos.mjs';
export async function exportModel(doc, records, styles, index, mode, pageIds) {
  if(pageIds!==undefined)validatePageIds(pageIds,doc.numPages);
  const pages=[];
  for(let n=1;n<=doc.numPages;n++){
    const p=await doc.getPage(n),v=p.getViewport({scale:1.7}),s=symbolStyle(styles(n));
    const point=(x,y)=>v.convertToPdfPoint(x,y);
    const arrows=records.filter(a=>a.page===n).map(a=>{
      const s=symbolStyle(arrowStyle(a,styles(n)));const x=a.x*Math.ceil(v.width),y=a.y*Math.ceil(v.height),c=Math.cos(a.angle),d=Math.sin(a.angle),q=Math.PI/7;
      return {arrowId:a.id,photoId:a.photoId||null,number:photoNumber(index.get(a.photoId),mode),
        center:point(x,y),lineStart:point(x+c*s.circle,y+d*s.circle),tip:point(x+c*s.length,y+d*s.length),
        headLeft:point(x+c*s.length-Math.cos(a.angle-q)*s.head,y+d*s.length-Math.sin(a.angle-q)*s.head),
        headRight:point(x+c*s.length-Math.cos(a.angle+q)*s.head,y+d*s.length-Math.sin(a.angle+q)*s.head),
        circleRadius:s.circle/v.scale,lineWidth:s.line/v.scale,fontSize:s.fontSize/v.scale,
        normalized:{x:a.x,y:a.y},clockwiseAngleRadians:a.angle};
    });
    pages.push({page:n,...(pageIds?{pageId:pageIds[n-1]}:{}),pdfBox:p.view,rotation:p.rotate,userUnit:p.userUnit||1,style:{...s},arrows});
  }
  return {format:'YASHI_CAD_EXCHANGE',version:1,numberingMode:mode,coordinates:'PDF user-space: x right, y up; page rotation in degrees; multiply by userUnit*25.4/72 for paper mm. Drawing scale is not inferred.',pages};
}
export async function makePdf(bytes,model,fontData){
  const doc=await PDFDocument.load(bytes),font=await embedNumberFont(doc,fontData),color=rgb(.8,0,0);
  for(const info of model.pages){const p=doc.getPage(info.page-1);
    for(const a of info.arrows){if(a.number===null)continue;
      const [x,y]=a.center;
      p.drawCircle({x,y,size:a.circleRadius,borderColor:color,borderWidth:a.lineWidth});
      p.drawLine({start:{x:a.lineStart[0],y:a.lineStart[1]},end:{x:a.tip[0],y:a.tip[1]},thickness:a.lineWidth,color,lineCap:0});
      const [tx,ty]=a.tip;
      p.drawSvgPath(`M 0 0 L ${a.headLeft[0]-tx} ${ty-a.headLeft[1]} L ${a.headRight[0]-tx} ${ty-a.headRight[1]} Z`,{x:tx,y:ty,color});
      const layout=numberLayout(a.number,a.fontSize,a.circleRadius,t=>font.widthOfTextAtSize(t,1)),text=layout.text,size=layout.fontSize;
      // Text baseline is rotated with the PDF page so the displayed number remains horizontal.
      const angle=info.rotation*Math.PI/180,dx=layout.baseline[0],dy=layout.baseline[1];
      p.drawText(text,{x:x+dx*Math.cos(angle)-dy*Math.sin(angle),y:y+dx*Math.sin(angle)+dy*Math.cos(angle),size,font,color,rotate:{type:'degrees',angle:info.rotation}});
    }
  }
  return doc.save();
}

export async function cadWithPdf(model,bytes,fileName,fontData){
 validatePageIds(model.pages.map(p=>p.pageId),model.pages.length);
 const data=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);let text='';for(let i=0;i<data.length;i+=32768)text+=String.fromCharCode(...data.subarray(i,i+32768));
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',data)),b=>b.toString(16).padStart(2,'0')).join('');
 return {...await addSymbolSpecification(model,fontData),version:2,sourcePdf:{fileName:fileName||'元図.pdf',mimeType:'application/pdf',encoding:'base64',pageCount:model.pages.length,byteLength:data.length,sha256:hash,data:btoa(text)}};
}
