// A deliberately digit-only adapter for the bundled TrueType font. Ledger numbers
// are positive safe integers; this is not a general text shaping engine.
export const FONT_URL=new URL('./lib/standard_fonts/LiberationSans-Bold.ttf',import.meta.url);
export const FONT_FAMILY='Yashi Number';
let loaded,canvasReady;
export function parseNumberFont(bytes){
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),u=p=>v.getUint16(p),s=p=>v.getInt16(p),d=p=>v.getUint32(p),tables={};
 for(let i=0;i<u(4);i++){const p=12+i*16;tables[String.fromCharCode(...bytes.subarray(p,p+4))]=d(p+8)}
 const h=tables.head,hh=tables.hhea,os=tables['OS/2'],post=tables.post,cmap=tables.cmap;
 let map;
 for(let i=0;i<u(cmap+2);i++){const p=cmap+4+i*8,t=cmap+d(p+4);if(u(t)===4&&(u(p)===0||u(p)===3)){map=t;break}}
 if(map===undefined)throw Error('番号フォントの文字対応表がありません。');
 const count=u(map+6)/2,end=map+14,start=end+count*2+2,delta=start+count*2,range=delta+count*2;
 function glyphId(cp){for(let i=0;i<count;i++){if(cp<u(start+i*2)||cp>u(end+i*2))continue;const r=u(range+i*2);if(!r)return(cp+s(delta+i*2))&65535;const g=u(range+i*2+r+2*(cp-u(start+i*2)));return g?(g+s(delta+i*2))&65535:0}return 0}
 const glyphs=new Map();for(let cp=48;cp<=57;cp++){const id=glyphId(cp);if(!id)throw Error('番号フォントに数字がありません。');glyphs.set(cp,{id,codePoints:[cp],advanceWidth:u(tables.hmtx+4*Math.min(id,u(hh+34)-1))})}
 const font={unitsPerEm:u(h+18),postscriptName:'LiberationSans-Bold',ascent:s(hh+4),descent:s(hh+6),capHeight:u(os)>=2?s(os+88):s(hh+4),xHeight:u(os)>=2?s(os+86):0,italicAngle:v.getInt32(post+4)/65536,
 bbox:{minX:s(h+36),minY:s(h+38),maxX:s(h+40),maxY:s(h+42)},post:{isFixedPitch:!!d(post+12)},head:{macStyle:{italic:false}},characterSet:[...glyphs.keys()],glyphForCodePoint:cp=>glyphs.get(cp),
 layout(text){if(!/^[0-9]+$/.test(text))throw Error('矢視番号は数字のみ使用できます。');return {glyphs:[...text].map(c=>glyphs.get(c.charCodeAt(0)))}}};
 return {bytes,font,widthAtOne:text=>font.layout(text).glyphs.reduce((n,g)=>n+g.advanceWidth,0)/font.unitsPerEm};
}
export function loadNumberFont(){return loaded??=(async()=>{const r=await fetch(FONT_URL);if(!r.ok)throw Error('番号フォントを読み込めません。');return parseNumberFont(new Uint8Array(await r.arrayBuffer()))})().catch(e=>{loaded=null;throw e})}
export function prepareCanvasFont(){return canvasReady??=(async()=>{const data=await loadNumberFont();const face=new FontFace(FONT_FAMILY,data.bytes,{weight:'700'});await face.load();document.fonts.add(face);return data})().catch(e=>{canvasReady=null;throw e})}
export async function embedNumberFont(doc,data){data??=await loadNumberFont();doc.registerFontkit({create:()=>data.font});return doc.embedFont(data.bytes,{subset:false,customName:'Yashi-LiberationSans-Bold'})}
export function numberLayout(number,fontSize,circleRadius,widthAtOne){const text=String(number),width=widthAtOne(text),size=Math.min(fontSize,circleRadius*1.65/width);return {text,fontSize:size,width:width*size,baseline:[-width*size/2,-size*.35]}}
