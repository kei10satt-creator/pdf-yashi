import {fontLicense} from './font-license.mjs';
import {loadNumberFont,numberLayout} from './number-font.mjs';
export const MM_PER_POINT=25.4/72;
export function paperCoordinates(page){
 const [x0,y0,x1,y1]=page.pdfBox,k=(page.userUnit||1)*MM_PER_POINT,r=((page.rotation%360)+360)%360;
 const matrix=r===0?[k,0,0,k,-x0*k,-y0*k]:r===90?[0,-k,k,0,-y0*k,x1*k]:r===180?[-k,0,0,-k,x1*k,y1*k]:r===270?[0,k,-k,0,y1*k,-x0*k]:null;
 if(!matrix)throw Error('PDFページの回転角を確認してください。');
 return {unit:'mm-paper',origin:'displayed PDF box bottom-left',xDirection:'right',yDirection:'up',pdfToPaper:matrix,width:(r%180?y1-y0:x1-x0)*k,height:(r%180?x1-x0:y1-y0)*k,
 normalized:{origin:'displayed PDF top-left',xDirection:'right',yDirection:'down',viewportScale:1.7,width:Math.ceil((r%180?y1-y0:x1-x0)*(page.userUnit||1)*1.7),height:Math.ceil((r%180?x1-x0:y1-y0)*(page.userUnit||1)*1.7)}};
}
export function mapPoint(m,p){return [m[0]*p[0]+m[2]*p[1]+m[4],m[1]*p[0]+m[3]*p[1]+m[5]]}
const clean=n=>Math.abs(n)<1e-10?0:Number(n.toPrecision(12));
export async function addSymbolSpecification(model,fontData){
 const font=fontData??await loadNumberFont(),definitions=[],known=new Map();
 const pages=model.pages.map(page=>{
  const k=(page.userUnit||1)*MM_PER_POINT,coordinates=paperCoordinates(page);
  const arrows=page.arrows.map(a=>{
   const center=mapPoint(coordinates.pdfToPaper,a.center),tip=mapPoint(coordinates.pdfToPaper,a.tip),angle=Math.atan2(tip[1]-center[1],tip[0]-center[0]),c=Math.cos(angle),s=Math.sin(angle);
   const local=p=>{const q=mapPoint(coordinates.pdfToPaper,p),x=q[0]-center[0],y=q[1]-center[1];return [clean(c*x+s*y),clean(-s*x+c*y)]};
   const start=local(a.lineStart),end=local(a.tip),left=local(a.headLeft),right=local(a.headRight);
   // The legacy PDF geometry is authoritative, including userUnit behavior.
   const shape={circleDiameter:clean(a.circleRadius*2*k),arrowLength:end[0],arrowHeadSize:clean(Math.hypot(left[0]-end[0],left[1]-end[1])),lineWidth:clean(a.lineWidth*k),fontSize:clean(a.fontSize*k),textWidth:clean(a.circleRadius*1.65*k),
    circle:{center:[0,0],radius:clean(a.circleRadius*k),fill:null},shaft:{start,end},head:{points:[end,left,right],fill:true},strokeColor:[.8,0,0],lineCap:'butt',lineJoin:'miter'};
   // Tolerant numeric canonicalization avoids one definition per direction.
   const key=JSON.stringify(shape);let ref=known.get(key);if(!ref){ref='shape-'+(definitions.length+1);known.set(key,ref);definitions.push({id:ref,...shape})}
   const label=a.number===null?null:numberLayout(a.number,a.fontSize*k,a.circleRadius*k,font.widthAtOne);
   return {...a,vectorworks:{symbolRef:ref,position:center,rotationRadians:angle,visible:a.number!==null,label:label?{...label,rotationRadians:0}:null}};
  });return {...page,paperCoordinates:coordinates,arrows};
 });
 let binary='';for(let i=0;i<font.bytes.length;i+=32768)binary+=String.fromCharCode(...font.bytes.subarray(i,i+32768));
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',font.bytes)),b=>b.toString(16).padStart(2,'0')).join('');
 return {...model,pages,vectorworksSymbol:{schemaVersion:1,name:'YASHI_Arrow',sizeMode:'paper',unit:'mm-paper',referenceRendering:'exported PDF',localAxes:'circle center; +X toward arrow tip; +Y left of +X; counterclockwise instance rotation',definitions,
  numberText:{independentOfSymbolRotation:true,color:[.8,0,0],font:{family:'Liberation Sans',postScriptName:'LiberationSans-Bold',weight:700,fileName:'LiberationSans-Bold.ttf',mimeType:'font/ttf',encoding:'base64',sha256:hash,data:btoa(binary)},fontSizeMeaning:'em height in paper mm; point size = mm * 72 / 25.4',fit:'uniform shrink to circleRadius * 1.65; no horizontal compression',baseline:'center + [-actualTextWidth/2, -actualFontSize*0.35]',licenseFile:'LICENSE_LIBERATION',licenseText:fontLicense,licenseNotice:'Liberation font: GPL v2 with font embedding exception; see bundled license.'}}};
}
