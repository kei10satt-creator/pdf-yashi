import {withPageIdentity,newPageId} from './page-identity.mjs';
import {PDFDocument} from './lib/pdf-lib.mjs';
import {pageOf} from './pages.mjs';
export async function deletePdfPages(source,pages){
 const doc=await PDFDocument.load(source.pdfBytes),count=doc.getPageCount(),chosen=[...new Set(pages)].sort((a,b)=>a-b);
 if(!chosen.length||chosen.some(n=>!Number.isInteger(n)||n<1||n>count))throw Error('削除するページがありません。');
 if(chosen.length>=count)throw Error('最後の1ページは削除できません。先にページを追加してください。');
 source=await withPageIdentity(source,count);
 const removed=new Set(chosen),remap=n=>n-chosen.filter(p=>p<n).length;
 for(const n of [...chosen].reverse())doc.removePage(n-1);
 const styles={};for(const [n,s] of Object.entries(source.pageStyles||{}))if(!removed.has(Number(n)))styles[remap(Number(n))]={...s};
 const arrows=(source.arrows||[]).filter(a=>!removed.has(pageOf(a))).map(a=>({...a,page:remap(pageOf(a))}));
 return {...source,pageIds:source.pageIds.filter((id,i)=>!removed.has(i+1)),pdfBytes:await doc.save(),arrows,pageStyles:styles,currentPage:Math.min(remap(source.currentPage||1),count-chosen.length)};
}
export async function deletePdfPage(source,page){return deletePdfPages(source,[page])}
export async function appendPdfPages(source,bytes){
 const target=await PDFDocument.load(source.pdfBytes),added=await PDFDocument.load(bytes),offset=target.getPageCount();
 source=await withPageIdentity(source,offset);
 if(!added.getPageCount())throw Error('追加するPDFにページがありません。');
 const copies=await target.copyPages(added,added.getPageIndices());for(const page of copies)target.addPage(page);
 const pageStyles={...source.pageStyles};for(let n=1;n<=copies.length;n++)pageStyles[offset+n]={...source.style};
 return {...source,pageIds:[...source.pageIds,...copies.map(()=>newPageId())],pdfBytes:await target.save(),arrows:(source.arrows||[]).map(a=>({...a})),pageStyles,currentPage:offset+1};
}
