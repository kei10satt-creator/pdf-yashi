# CAD交換JSON version 2

v0.9.6でも交換形式を維持します。詳細はVectorworks_CAD交換JSON仕様.mdを参照してください。
