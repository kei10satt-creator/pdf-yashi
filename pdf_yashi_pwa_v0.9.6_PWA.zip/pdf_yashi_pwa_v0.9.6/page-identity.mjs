import {PDFDocument} from './lib/pdf-lib.mjs';
function randomId(){if(crypto.randomUUID)return crypto.randomUUID();const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('')}
export function newPageId(){return 'page-'+randomId()}
export function validatePageIds(ids,count){
 if(!Array.isArray(ids)||ids.length!==count||ids.some(id=>typeof id!=='string'||!id.trim())||new Set(ids).size!==count)throw Error('ページIDとPDFページの対応が不正です。元の案件ファイルを確認してください。');
 return [...ids];
}
export async function withPageIdentity(source,count){
 const cadProjectId=source.cadProjectId||source.projectId||randomId();
 if(typeof cadProjectId!=='string'||!cadProjectId.trim())throw Error('連携用の案件IDが不正です。');
 if(count===undefined)count=source.pageIds?.length??(await PDFDocument.load(source.pdfBytes)).getPageCount();
 if(!Number.isInteger(count)||count<1)throw Error('PDFのページ数を確認してください。');
 if(source.pageIds!==undefined)return {...source,cadProjectId,pageIds:validatePageIds(source.pageIds,count)};
 // Deterministic, one-time migration lets the same legacy .yashi opened on
 // different devices acquire the same identity. Never recalculate after edits.
 const pageIds=await Promise.all(Array.from({length:count},async(_,i)=>{
  const bytes=new TextEncoder().encode(JSON.stringify(['YASHI_LEGACY_PAGE_V1',cadProjectId,i+1]));
  return 'page-'+Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
 }));
 return {...source,cadProjectId,pageIds};
}
export async function mapPageIdentity(source,oldCount,mappings,newCount){
 const before=await withPageIdentity(source,oldCount),ids=Array.from({length:newCount},newPageId),usedOld=new Set(),usedNew=new Set();
 for(const m of mappings){if(!Number.isInteger(m.old)||m.old<1||m.old>oldCount||!Number.isInteger(m.target)||m.target<1||m.target>newCount||usedOld.has(m.old)||usedNew.has(m.target))throw Error('ページIDを継承する対応関係が不正です。');usedOld.add(m.old);usedNew.add(m.target);ids[m.target-1]=before.pageIds[m.old-1]}
 if(usedOld.size!==oldCount)throw Error('旧PDFのすべてのページに対応先が必要です。');
 return validatePageIds(ids,newCount);
}
