import {FONT_FAMILY,numberLayout} from './number-font.mjs';
// Geometry follows existing PDF output. userUnit only multiplies the legacy
// radius/stroke/font fields; endpoint geometry is already in viewport pixels.
export function drawArrowSymbol(c,p,angle,s,number,fontData,userUnit=1,{color='#c00',temporary=false}={}){
 const x=p.x+Math.cos(angle)*s.length,y=p.y+Math.sin(angle)*s.length,r=s.circle*userUnit;
 c.save();c.strokeStyle=c.fillStyle=color;c.lineWidth=s.line*userUnit;c.lineCap='butt';c.lineJoin='miter';
 if(temporary){c.globalAlpha=.82;c.setLineDash([10,7])}
 c.beginPath();c.arc(p.x,p.y,r,0,Math.PI*2);c.stroke();
 c.beginPath();c.moveTo(p.x+Math.cos(angle)*s.circle,p.y+Math.sin(angle)*s.circle);c.lineTo(x,y);c.stroke();
 c.setLineDash([]);c.beginPath();c.moveTo(x,y);c.lineTo(x-Math.cos(angle-Math.PI/7)*s.head,y-Math.sin(angle-Math.PI/7)*s.head);c.lineTo(x-Math.cos(angle+Math.PI/7)*s.head,y-Math.sin(angle+Math.PI/7)*s.head);c.closePath();c.fill();
 if(!temporary&&number!==null&&number!==undefined){const t=numberLayout(number,s.fontSize*userUnit,r,fontData.widthAtOne);c.font='700 '+t.fontSize+'px "'+FONT_FAMILY+'"';c.textAlign='left';c.textBaseline='alphabetic';c.fontKerning='none';c.fillText(t.text,p.x+t.baseline[0],p.y-t.baseline[1])}
 c.restore();
}
