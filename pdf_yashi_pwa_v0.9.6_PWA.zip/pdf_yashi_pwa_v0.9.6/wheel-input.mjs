export function wheelIntent(e,mode='auto',recentPan=false){
 if(e.ctrlKey)return 'pinch';
 if(mode==='trackpad')return 'pan';if(mode==='mouse')return 'zoom';
 if(e.shiftKey||e.deltaX)return 'pan';
 if(e.deltaMode!==0)return 'zoom';
 const n=Math.abs(e.deltaY);
 // Windows detented wheels commonly report integral 100/120 px steps. The
 // browser exposes no reliable device ID; users can override the heuristic.
 return !recentPan&&n>=80&&(n%100===0||n%120===0)?'zoom':'pan';
}
