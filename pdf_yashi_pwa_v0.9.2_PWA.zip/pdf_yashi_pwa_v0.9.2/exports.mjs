import {symbolStyle} from './registration.mjs';
import {PDFDocument, StandardFonts, rgb} from './lib/pdf-lib.mjs';
import {photoNumber} from './photos.mjs';
export async function exportModel(doc, records, styles, index, mode) {
  const pages=[];
  for(let n=1;n<=doc.numPages;n++){
    const p=await doc.getPage(n),v=p.getViewport({scale:1.7}),s=symbolStyle(styles(n));
    const point=(x,y)=>v.convertToPdfPoint(x,y);
    const arrows=records.filter(a=>a.page===n).map(a=>{
      const x=a.x*Math.ceil(v.width),y=a.y*Math.ceil(v.height),c=Math.cos(a.angle),d=Math.sin(a.angle),q=Math.PI/7;
      return {arrowId:a.id,photoId:a.photoId||null,number:photoNumber(index.get(a.photoId),mode),
        center:point(x,y),lineStart:point(x+c*s.circle,y+d*s.circle),tip:point(x+c*s.length,y+d*s.length),
        headLeft:point(x+c*s.length-Math.cos(a.angle-q)*s.head,y+d*s.length-Math.sin(a.angle-q)*s.head),
        headRight:point(x+c*s.length-Math.cos(a.angle+q)*s.head,y+d*s.length-Math.sin(a.angle+q)*s.head),
        circleRadius:s.circle/v.scale,lineWidth:s.line/v.scale,fontSize:s.fontSize/v.scale,
        normalized:{x:a.x,y:a.y},clockwiseAngleRadians:a.angle};
    });
    pages.push({page:n,pdfBox:p.view,rotation:p.rotate,userUnit:p.userUnit||1,style:{...s},arrows});
  }
  return {format:'YASHI_CAD_EXCHANGE',version:1,numberingMode:mode,coordinates:'PDF user-space: x right, y up; page rotation in degrees; multiply by userUnit*25.4/72 for paper mm. Drawing scale is not inferred.',pages};
}
export async function makePdf(bytes,model){
  const doc=await PDFDocument.load(bytes),font=await doc.embedFont(StandardFonts.HelveticaBold),color=rgb(.8,0,0);
  for(const info of model.pages){const p=doc.getPage(info.page-1);
    for(const a of info.arrows){if(a.number===null)continue;
      const [x,y]=a.center;
      p.drawCircle({x,y,size:a.circleRadius,borderColor:color,borderWidth:a.lineWidth});
      p.drawLine({start:{x:a.lineStart[0],y:a.lineStart[1]},end:{x:a.tip[0],y:a.tip[1]},thickness:a.lineWidth,color});
      const [tx,ty]=a.tip;
      p.drawSvgPath(`M 0 0 L ${a.headLeft[0]-tx} ${ty-a.headLeft[1]} L ${a.headRight[0]-tx} ${ty-a.headRight[1]} Z`,{x:tx,y:ty,color});
      const text=String(a.number),size=Math.min(a.fontSize,a.circleRadius*1.65/font.widthOfTextAtSize(text,1));
      // Text baseline is rotated with the PDF page so the displayed number remains horizontal.
      const angle=info.rotation*Math.PI/180,dx=-font.widthOfTextAtSize(text,size)/2,dy=-size*.35;
      p.drawText(text,{x:x+dx*Math.cos(angle)-dy*Math.sin(angle),y:y+dx*Math.sin(angle)+dy*Math.cos(angle),size,font,color,rotate:{type:'degrees',angle:info.rotation}});
    }
  }
  return doc.save();
}
