import {PDFDocument} from './lib/pdf-lib.mjs';
import {pageOf} from './pages.mjs';
export async function deletePdfPage(source,page){
 const doc=await PDFDocument.load(source.pdfBytes),count=doc.getPageCount();
 if(!Number.isInteger(page)||page<1||page>count)throw Error('削除するページがありません。');
 if(count===1)throw Error('最後の1ページは削除できません。先にページを追加してください。');
 doc.removePage(page-1);
 const styles={};for(const [key,s] of Object.entries(source.pageStyles||{})){const n=Number(key);if(n!==page)styles[n>page?n-1:n]={...s}}
 const arrows=(source.arrows||[]).filter(a=>pageOf(a)!==page).map(a=>({...a,page:pageOf(a)>page?pageOf(a)-1:pageOf(a)}));
 const current=source.currentPage||1;
 return {...source,pdfBytes:await doc.save(),arrows,pageStyles:styles,currentPage:current>page?current-1:Math.min(current,count-1)};
}
export async function appendPdfPages(source,bytes){
 const target=await PDFDocument.load(source.pdfBytes),added=await PDFDocument.load(bytes),offset=target.getPageCount();
 if(!added.getPageCount())throw Error('追加するPDFにページがありません。');
 const copies=await target.copyPages(added,added.getPageIndices());for(const page of copies)target.addPage(page);
 const pageStyles={...source.pageStyles};for(let n=1;n<=copies.length;n++)pageStyles[offset+n]={...source.style};
 return {...source,pdfBytes:await target.save(),arrows:(source.arrows||[]).map(a=>({...a})),pageStyles,currentPage:offset+1};
}
